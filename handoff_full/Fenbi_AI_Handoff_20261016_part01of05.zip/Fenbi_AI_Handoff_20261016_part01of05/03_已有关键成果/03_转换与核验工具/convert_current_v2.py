#!/usr/bin/env python3
"""Convert the observed local JSON paper formats to the current single-paper V2.

No login, scraping, image download, inferred answers or invented statistics.
Usage: python3 convert_current_v2.py source.json --out output/paper
"""
import argparse
import hashlib
import json
import re
from html.parser import HTMLParser
from pathlib import Path

FIELDS=('id','globalId','subject','path','tags','year','order','stemHtml',
        'optionsHtml','answer','explanationHtml','source','demo','rate',
        'rateSource','totalCount','mostWrong')

class Images(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.urls=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower()=='img' and dict(attrs).get('src'):self.urls.append(dict(attrs)['src'])

def images(value):
    p=Images();p.feed(value or '');return p.urls

def normal(value):
    return re.sub(r'(<img\b[^>]*?\bsrc\s*=\s*["\'])//',r'\1https://',value or '',flags=re.I)

def walk(node,subject='未分类'):
    if node.get('nodeType')==1:subject=node['name'].replace('言语理解与表达','言语理解')
    if node.get('nodeType')==2:yield node,subject
    for child in node.get('children',[]):yield from walk(child,subject)

def letter(value):
    if value in ('A','B','C','D',None,''):return value or None
    raise ValueError('未支持的答案编码；不得猜测或自动填充：'+str(value))

def convert(raw):
    if isinstance(raw.get('data'),dict) and raw['data'].get('solutions'):raw=raw['data']
    if all(k in raw for k in ('name','question_count','card','materials','questions')):
        return {k:raw[k] for k in ('name','question_count','card','materials','questions')},[]
    notes=[];is_solution='solutions' in raw
    rows=raw.get('solutions') if is_solution else raw.get('questions')
    if not isinstance(rows,list) or not rows:raise ValueError('未找到受支持的solutions/questions题目数组')
    title=raw.get('name') or raw.get('title') or rows[0].get('paperName')
    if not title:raise ValueError('原件缺少试卷标题，请先核实卷身份')
    year_match=re.search(r'20\d{2}',title);default_year=int(year_match[0]) if year_match else None
    if is_solution:
        if not raw.get('card'):raise ValueError('solutions原件缺少card；无法核实原卷题序')
        by={str(q['globalId']):q for q in rows}
        if len(by)!=len(rows):raise ValueError('原始solutions的globalId重复')
        global_materials={str(m['globalId']):m for m in raw.get('materials',[])}
        ordered=[]
        for n,(node,subject) in enumerate(walk(raw['card']),1):
            q=by[str(node['key'])];opts=next((x['options'] for x in q.get('accessories',[]) if isinstance(x.get('options'),list)),None)
            choice=q.get('correctAnswer',{}).get('choice');answer='ABCD'[int(choice)] if str(choice) in ('0','1','2','3') else None
            ordered.append(dict(q,id='fenbi:'+str(q['globalId']),subject=subject,number=n,
                stemHtml=q.get('content',''),optionsHtml=opts or [],answer=answer,
                explanationHtml=q.get('solution') or None,
                materials=[global_materials[str(mid)] for mid in node.get('materialKeys',[])],
                originalPlatformId=q.get('id')))
        if len(ordered)!=len(rows):raise ValueError('card与solutions题量不符')
        rows=ordered
        notes.append('本次仅转换solutions内已有数据；没有自动读入其他统计文件，缺少正确率时保留null。')
    sections={};materials={};questions=[];provenance=[]
    for i,q in enumerate(rows,1):
        gid=str(q.get('globalId') or q.get('key') or '')
        if not gid:raise ValueError(f'第{i}题缺原始globalId/key；请先登记ID来源')
        subject=q.get('subject') or '未分类';subject=subject.replace('言语理解与表达','言语理解')
        number=q.get('paperNumber') or q.get('number') or q.get('order') or i
        section=sections.setdefault(subject,{'nodeType':1,'name':subject,'children':[]})
        keys=[];input_mats=q.get('materials') or []
        if q.get('materialHtml'):input_mats=[{'content':q['materialHtml']}]
        for m in input_mats:
            content=normal(m.get('content',''))
            if not content:continue
            mid=str(m.get('globalId') or m.get('id') or 'local-material:'+hashlib.sha256(content.encode()).hexdigest()[:20])
            if mid in materials and materials[mid]['content']!=content:raise ValueError('同一材料ID内容冲突：'+mid)
            materials[mid]={'globalId':mid,'content':content};keys.append(mid)
        section['children'].append({'nodeType':2,'key':gid,'materialKeys':keys})
        kp=[x.get('name') for x in q.get('keypoints',[]) if isinstance(x,dict)]
        kp=[x for x in kp if isinstance(x,str) and x];typ=q.get('type') if isinstance(q.get('type'),str) else None
        tags=list(dict.fromkeys(([typ] if typ else [])+kp+[x for x in q.get('tags',[]) if isinstance(x,str)]))
        path=q.get('path') or ([typ] if typ else [])
        if path and path[0]==subject:path=path[1:]
        stats=q.get('statistics') or {};rs=stats.get('raw') or {};mw=q.get('mostWrong',rs.get('mostWrongAnswer'))
        if isinstance(mw,dict):mw='ABCD'[int(mw['choice'])] if str(mw.get('choice')) in ('0','1','2','3') else None
        rate=q.get('rate',q.get('correctRatio'));answer=letter(q.get('answer'))
        questions.append(dict(id=str(q.get('id') or gid),globalId=gid,subject=subject,path=path,tags=tags,
            year=q.get('year') or default_year,order=number,
            stemHtml=normal(q.get('stemHtml') or q.get('stem') or ''),
            optionsHtml=[normal(x) for x in q.get('optionsHtml',[])],answer=answer,
            explanationHtml=normal(q.get('explanationHtml')) or None,
            source=q.get('source') or title,demo=bool(q.get('demo',False)),rate=rate,
            rateSource=q.get('rateSource') or stats.get('source'),
            totalCount=q.get('totalCount',rs.get('totalCount')),mostWrong=mw))
        provenance.append({'order':number,'globalId':gid,'originalId':q.get('originalPlatformId',q.get('platformId',q.get('id'))),'statistics':stats,'originalKeypoints':q.get('keypoints',[])})
    return {'name':title,'question_count':len(questions),'card':{'nodeType':0,'children':list(sections.values())},'materials':list(materials.values()),'questions':questions},notes+[{'questionProvenance':provenance}]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('source',type=Path);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    raw=json.loads(args.source.read_text(encoding='utf-8-sig'));paper,notes=convert(raw);qs=paper['questions'];errors=[]
    if paper['question_count']!=len(qs):errors.append('声明题数与实际题数不同')
    if [q['order'] for q in qs]!=list(range(1,len(qs)+1)):errors.append('题号不是原顺序1至N')
    if len({q['globalId'] for q in qs})!=len(qs):errors.append('卷内globalId重复')
    nodes=list(walk(paper['card']));mats={m['globalId']:m['content'] for m in paper['materials']}
    if [str(n['key']) for n,s in nodes]!=[q['globalId'] for q in qs]:errors.append('card与题目ID/顺序不一致')
    for q in qs:
        if set(q)!=set(FIELDS):errors.append(f"第{q['order']}题字段集合不一致")
        if not q.get('stemHtml') or len(q.get('optionsHtml',[]))!=4 or any(not str(x).strip() for x in q.get('optionsHtml',[])):errors.append(f"第{q['order']}题缺题干/四选项")
        if q['answer'] not in ('A','B','C','D',None):errors.append(f"第{q['order']}题答案编码错误")
        if q['rate'] is not None and (not isinstance(q['rate'],(int,float)) or not 0<=q['rate']<=100):errors.append(f"第{q['order']}题正确率错误")
    for node,sub in nodes:
        if any(mid not in mats for mid in node.get('materialKeys',[])):errors.append('材料引用缺失：'+str(node['key']))
    missing={'answers':[q['order'] for q in qs if not q['answer']],'explanations':[q['order'] for q in qs if not q['explanationHtml']],'classification':[q['order'] for q in qs if not q['path']],'rates':[q['order'] for q in qs if q['rate'] is None]}
    resources={}
    def add(html,ref):
        for idx,url in enumerate(images(html),1):
            record=resources.setdefault(url,{'mediaId':'media:'+hashlib.sha256(url.encode()).hexdigest()[:20],'url':url,'status':'unchecked','references':[]})
            record['references'].append(dict(ref,imageIndex=idx))
    for q in qs:
        for field in ('stemHtml','explanationHtml'):add(q[field],{'question':q['order'],'field':field})
        for i,opt in enumerate(q['optionsHtml']):add(opt,{'question':q['order'],'field':'optionsHtml','optionIndex':i})
    by_gid={q['globalId']:q['order'] for q in qs}
    for node,sub in nodes:
        for mid in node.get('materialKeys',[]):add(mats.get(mid,''),{'question':by_gid.get(str(node['key'])),'field':'materials.content','materialId':mid})
    report={'paper':paper['name'],'questions':len(qs),'materials':len(mats),'materialQuestionCount':sum(bool(n.get('materialKeys')) for n,s in nodes),'sourceSHA256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'errors':errors,'dataComplete':not(errors or missing['answers'] or missing['explanations']),'siteImportTested':False,'notes':notes}
    args.out.mkdir(parents=True,exist_ok=True)
    for filename,obj in [('paper_v2.json',paper),('audit.json',report),('missing.json',missing),('media_manifest.json',{'paper':paper['name'],'resources':list(resources.values()),'resourceCount':len(resources),'referenceCount':sum(len(x['references']) for x in resources.values()),'note':'仅建立索引，没有执行资源联网/解码检查'})]:
        (args.out/filename).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'paper':paper['name'],'questions':len(qs),'errors':errors,'dataComplete':report['dataComplete'],'answerMissing':len(missing['answers']),'out':str(args.out)},ensure_ascii=False))
    if errors:raise SystemExit(2)

if __name__=='__main__':main()
