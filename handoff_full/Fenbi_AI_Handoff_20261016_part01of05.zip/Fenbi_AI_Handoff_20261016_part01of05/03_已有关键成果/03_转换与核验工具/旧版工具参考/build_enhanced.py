#!/usr/bin/env python3
"""Reproducible adapter for the four existing, user-authorized local papers."""
import hashlib
import importlib.util
import json
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('prepare', OUT/'tools/prepare.py')
prepare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prepare)

class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts=[]
    def handle_data(self, value): self.parts.append(value)
    def handle_starttag(self, tag, attrs):
        if tag in ('br','p','div','tr'): self.parts.append('\n')

def plain(markup):
    parser=Text(); parser.feed(markup or '')
    value=''.join(parser.parts).strip()
    return value or ('[图片题面，见富文本]' if '<img' in (markup or '').lower() else '')

def save(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    sources={
        'national_admin_2026':'deliverables/2026国考行政执法卷_130题_完整图片公式.json',
        'national_city_2026':'deliverables/2026国考地市卷_130题_完整图片公式.json',
        'national_admin_2025':'deliverables/2025_pilot/2025_admin_source.json',
        'national_city_2025':'deliverables/2025_pilot/2025_city_source.json',
    }
    template=json.loads((ROOT/'upload/v2_paper_template(2).json').read_text())
    inventory=[]
    for key,source in sources.items():
        src=ROOT/source; raw=json.loads(src.read_text()); paper=prepare.convert(raw)
        folder=OUT/key; folder.mkdir(exist_ok=True)
        report=prepare.audit(paper)
        materials={m['globalId']:m for m in paper['materials']}
        nodes={q['key']:q for section in paper['card']['children'] for q in section['children']}
        site=[]; issues=[]; provenance=[]
        for q,original in zip(paper['questions'],raw['questions']):
            assert q['globalId']==str(original.get('globalId') or original.get('key') or original.get('id'))
            assert q['id']==str(original.get('id') or original.get('key') or q['globalId'])
            assert q['answer']==original.get('answer')
            assert q['stemHtml']==prepare.normalize_html(original.get('stemHtml') or original.get('stem') or '')
            assert q['optionsHtml']==[prepare.clean_option(x) for x in original.get('optionsHtml',[])]
            if q['answer'] not in ('A','B','C','D',None,''): issues.append({'question':q['order'],'issue':'invalid_answer'})
            if q['rate'] is not None and not (isinstance(q['rate'],(int,float)) and 0<=q['rate']<=100): issues.append({'question':q['order'],'issue':'invalid_rate'})
            for mid in nodes[q['globalId']]['materialKeys']: assert mid in materials
            row=dict(original)
            row.update(id=q['id'],globalId=q['globalId'],stem=original.get('stem') or plain(q['stemHtml']),
                options=[(str(x).strip() or plain(q['optionsHtml'][i])) for i,x in enumerate(original.get('options') or [plain(x) for x in q['optionsHtml']])],
                stemHtml=q['stemHtml'],optionsHtml=q['optionsHtml'],answer=q['answer'],
                explanation=original.get('explanation') or plain(q['explanationHtml']),explanationHtml=q['explanationHtml'],
                source=q['source'],subject=q['subject'],type=original.get('type') or '未分类',
                paperId=original.get('paperId') or key,paperName=paper['name'],paperNumber=q['order'],
                year=q['year'],region=original.get('region') or '国考',exam='国考',
                paperType=original.get('paperType') or ('行政执法' if 'admin' in key else '地市级'),
                materials=[materials[mid] for mid in nodes[q['globalId']]['materialKeys']],demo=False,
                rate=q['rate'],correctRatio=q['rate'])
            site.append(row)
            provenance.append({'id':q['id'],'globalId':q['globalId'],'order':q['order'],
                'statistics':original.get('statistics'),'sourceType':original.get('type'),
                'classificationMissing':not bool(original.get('type') or original.get('tags') or original.get('keypoints'))})
        assert set(paper)==set(template)
        assert all(set(q)==set(template['questions'][0]) for q in paper['questions'])
        report.update(sourceFile=source,sourceSHA256=hashlib.sha256(src.read_bytes()).hexdigest(),
            templateKeysMatch=True,sourceTextAndOptionsMatch=True,sourceAnswersUnchanged=True,
            stableIdsPreserved=True,materialReferencesValid=True,semanticIssues=issues,
            detailedTypeMissing=[x['order'] for x in provenance if x['classificationMissing']],
            verificationScope='local structural and source-preservation checks; not independent proof of answer correctness')
        save(folder/'paper_v2.json',paper)
        save(folder/('site_import.json' if report['dataComplete'] else 'site_import_pending.json'),
             {'format':'jiangsu-question-bank','version':2,'questions':site})
        save(folder/'audit.json',report)
        save(folder/'missing.json',{'paper':paper['name'],'answers':report['answerMissing'],
            'explanations':report['explanationMissing'],'detailedType':report['detailedTypeMissing'],
            'statistics':[q['order'] for q in paper['questions'] if q['rate'] is None],
            'importBlockedByMissingAnswers':bool(report['answerMissing'])})
        save(folder/'source_provenance.json',{'paper':paper['name'],'questions':provenance})
        save(folder/'media_manifest.json',prepare.media(paper))
        inventory.append({'paper':key,'source':source,'questions':len(site),'complete':report['dataComplete'],'sha256':report['sourceSHA256']})
    save(OUT/'local_source_inventory.json',inventory)
    print(json.dumps(inventory,ensure_ascii=False))

if __name__=='__main__': main()
