#!/usr/bin/env python3
import collections,concurrent.futures,json,re
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import unquote,quote
OUT=Path(__file__).resolve().parents[1]
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
catalog=json.loads((OUT/'source_catalog.json').read_text());by={x['key']:x for x in catalog}
filenames=json.loads((OUT/'repository_filename_inventory.json').read_text())['matches']
targets=json.loads((OUT.parent/'个人真题数据库_25套阶段包_20261015/targets_25.json').read_text())['targets']
records=[]
for target in targets:
 key=target['key'];year=target['year'];cat=target['category'];region=target['region']
 if region=='国考':
  category='行政执法' if 'admin' in key else '地市级';region_token='国家公务员'
  primary='national_2022_download' if year==2022 else 'national_2024_university' if year==2024 else f'national_{year}'
 elif region=='江苏省考':category='B类';region_token='江苏';primary=f'jiangsu_{year}'
 else:category=cat;region_token='浙江';primary='zhejiang_2022_B' if year==2022 and cat=='B类' else 'zhejiang_2022_2024' if year<=2024 else f'zhejiang_{year}'
 source=by.get(primary)
 matching_files=[x for x in filenames if str(year) in x and region_token in x and category in x]
 candidates=[]
 if source:
  for a in source.get('attachments',[])+source.get('examLinks',[]):
   label=unquote(a['title']+' '+a['url'])
   if str(year) in label and ('行测' in label or '行政职业' in label):
    if region=='国考':match=('行政执法' in label) if 'admin' in key else ('地市' in label or '市地' in label)
    else:match=(cat[0] in label) if region=='浙江省考' else ('B类' in label or 'B卷' in label)
    if match and a not in candidates:candidates.append(a)
 # Preserve search-discovered PDF links as metadata; no exam text was exported.
 if key=='national_city_2023':candidates.append({'title':'2023国考市地级行测题本','url':'https://upload.xingguanggongkao.com/pdf/2023%E5%B9%B4%E5%9B%BD%E8%80%83%E8%A1%8C%E6%B5%8B%E7%9C%9F%E9%A2%98%EF%BC%88%E5%B8%82%E5%9C%B0%E7%BA%A7%EF%BC%89.pdf?time=1700213002','verification':'search result metadata'})
 if key=='national_admin_2023':candidates.append({'title':'2023国考行政执法题目及答案目录','url':'https://www.jiaoyubao.cn/baike/8606.html','verification':'search result metadata'})
 r={**target,'sourceStatus':'local_processed' if year in (2025,2026) and region=='国考' else 'candidates_found',
    'searched':True,'searchQuery':f'{year} {region} {cat} 行测 真题 官方 PDF 开放许可',
    'primarySource':source,'candidateLinks':candidates,'repositoryFilenameEvidence':matching_files,
    'repositoryURL':'https://github.com/ERRRC/xingcezhenti','repositoryLicense':'not declared in GitHub repository metadata',
    'fullNewExamContentCopied':False}
 if r['sourceStatus']=='local_processed':r['remainingBlockers']=['2025答案与解析缺失'] if year==2025 else []
 else:
  blockers=[]
  if source and source.get('access')=='tool_access_failed':blockers.append({'type':'tool_access_failed','tool':'Python urllib.request','url':source['url'],'error':source.get('error')})
  if source and source.get('bulkConversionPermission') in ('explicit_copy_restriction','restricted_republication'):blockers.append({'type':'source_restriction','detail':source['finding']})
  else:blockers.append({'type':'permission_unconfirmed','detail':'未确认覆盖该整卷题干、解析及图片的完整转换许可；下载/在线可读不自动证明许可。'})
  if not matching_files and not candidates:
   blockers.append({'type':'exact_paper_not_verified','detail':'本轮检索未核实到该年该类别的可直接处理完整原卷；不以其他年份或其他卷别替代。'})
   r['sourceStatus']='exact_paper_not_verified'
  r['remainingBlockers']=blockers
 save(OUT/'source_records'/f'{key}.json',r);records.append(r)
save(OUT/'targets_25_checked.json',{'count':25,'records':records,'note':'每个目标均有检索记录；元数据候选不等于题目内容获授权或已完成。国考四卷为本地已有资料，本轮没有新增完整外部试卷。'})
# Inspect download responses only: a PDF signature is not proof of copying permission.
links=[]
for r in records:
 if r['sourceStatus']!='local_processed':
  for a in r['candidateLinks']:
   if '.pdf' in a['url'].lower() and a['url'] not in [x['url'] for x in links]:links.append(a)
def head(a):
 r=dict(a)
 try:
  with urlopen(Request(quote(a['url'],safe=':/?=&%'),headers={'User-Agent':'Mozilla/5.0','Range':'bytes=0-1023'}),timeout=12) as f:
   b=f.read(1024);r.update(status=f.status,contentType=f.headers.get('Content-Type'),pdfSignature=b.startswith(b'%PDF-'),bytesInspected=len(b))
 except Exception as e:r.update(errorType=type(e).__name__,error=str(e))
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(head,links))
save(OUT/'attachment_access_audit.json',{'scope':'Only PDF header bytes inspected; no new paper content exported','results':results})
print(json.dumps({'targetsChecked':len(records),'statuses':dict(collections.Counter(r['sourceStatus'] for r in records)),'downloadCandidatesChecked':len(results),'pdfHeadersConfirmed':sum(x.get('pdfSignature',False) for x in results),'accessErrors':[{'url':x['url'],'error':x['error']} for x in results if x.get('error')]},ensure_ascii=False))
