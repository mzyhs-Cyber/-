#!/usr/bin/env python3
"""Check image URLs in a manifest without modifying the paper JSON."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import socket
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def inspect(record, timeout):
    url = record['url']
    result = {'mediaId': record['mediaId'], 'url': url,
              'references': record['references'], 'status': 'unknown'}
    if not url.startswith(('http://', 'https://')):
        result.update(status='unsupported_url', detail='不是 HTTP(S) URL')
        return result
    try:
        request = Request(url, headers={'User-Agent': 'Mozilla/5.0 (compatible; MediaAudit/1.0)',
                                        'Range': 'bytes=0-1023'})
        with urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get('Content-Type', '').split(';')[0].lower()
            head = response.read(32)
            if content_type.startswith('image/') or head.startswith((b'\x89PNG', b'\xff\xd8', b'GIF8', b'RIFF', b'<svg')):
                result.update(status='http_image_ok', httpStatus=response.status, contentType=content_type)
            else:
                result.update(status='non_image_response', httpStatus=response.status, contentType=content_type)
    except HTTPError as e:
        result.update(status='http_not_found' if e.code == 404 else 'http_error', httpStatus=e.code)
    except (URLError, TimeoutError, socket.timeout) as e:
        result.update(status='network_error', detail=str(e.reason if isinstance(e, URLError) else e))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--timeout', type=float, default=8)
    parser.add_argument('--workers', type=int, default=8)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding='utf-8'))
    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, 16))) as pool:
        results = list(pool.map(lambda x: inspect(x, args.timeout), manifest['media']))
    audit = {'paper': manifest['paper'], 'checkedAt': datetime.now(timezone.utc).isoformat(),
             'scope': 'HTTP 内容检查；浏览器实际显示仍需另行检查',
             'results': results}
    args.out.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    counts = {status: sum(r['status'] == status for r in results)
              for status in sorted({r['status'] for r in results})}
    print(json.dumps(counts, ensure_ascii=False))


if __name__ == '__main__':
    main()
