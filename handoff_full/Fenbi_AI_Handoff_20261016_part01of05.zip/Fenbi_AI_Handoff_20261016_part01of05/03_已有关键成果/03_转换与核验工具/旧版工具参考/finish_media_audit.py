#!/usr/bin/env python3
import base64,collections,hashlib,io,json
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from PIL import Image
OUT=Path(__file__).resolve().parents[1]
# Evidence read from document.images through the browser tool on 2026-10-15.
# Only resource identities and loading state were read; no question text copied.
ADMIN='''193820948686cd1.png
formula:0g7lNAhqg8MyDHebDmP1zd31AlkRyOiBb6W4hzsa2y8
formula:UKj7HnUHQbeLnBSc7gHr8OU0WKOa86uPrukgrU-UUqU
formula:wklQV3lWWZe0ZsXiIiJerguwphc0RI6y8Vk3Sv5Nvxg
formula:7cnbVC9RKAvUmiYGY9o6i71ggyayxerbBqjS9XdIQpk
1938142939d5529.png
formula:76UwJ108QHBDzedz9Ej6AadwU2RKDdSFugHxWFT0ENo
formula:36RPUrR71H9hT-mq-boZFQ
formula:EKniczxCSnZOBvVtusQdfg
formula:oCdxKXzR8BUuBC5RE79j8w
formula:ltWRHxYrQOgUIVABQt-ZgQ
193819d443fbf6f.png
19381806b516105.png
1938173ed745d4b.png
193819194752338.png
19381b61ea714a5.png
19381dc08764e3b.png
193dc81c67f53e4.png
19381e7b74f4619.png
19381ca53c2dac3.png
19381cb680845c4.png
19381a4c0b7f5b1.png
19381a4cefc6718.png
19381a4dd8d0f2d.png
19381a4f07a5311.png
19380ecfb139b5a.png
19381090da73353.png
1938121348ac685.png
193812bd5bda577.png
193814907fc4a08.png
193814942ee32be.png
19381082320a22b.png
1938109c9fbb3d9.png
193811c5127e6d0.png
193811a03bac859.png'''
CITY='''formula:f9TuQnkeKdRuT6M4Z4jTA9mqak1_Uqnsf0BNS0hogPg
formula:ziZ7sjbex-7NaVJQIpONNUsH3aWCThEUJctpbEQNFR8
formula:0g7lNAhqg8MyDHebDmP1zd31AlkRyOiBb6W4hzsa2y8
formula:UKj7HnUHQbeLnBSc7gHr8OU0WKOa86uPrukgrU-UUqU
formula:wklQV3lWWZe0ZsXiIiJerguwphc0RI6y8Vk3Sv5Nvxg
formula:7cnbVC9RKAvUmiYGY9o6i71ggyayxerbBqjS9XdIQpk
1938230c68cd368.png
1938230d4e599e2.png
1938230e37042ed.png
1938230f0d88bec.png
formula:s8T2i2Zf7kUHySapnkekhQ
formula:9WX89o_zGBHECSf2JQG1Tw
formula:Z6p_l7YxCw4gpNnieBdBUw
formula:QKd_XChRjvv1wOIvFaawUA
formula:3HlpSdpRxWCuIxBoRz8Cpw
formula:1sgIdcggZt1F799YQvTFOg
formula:UfiuBHmaZv335Xi6DA_erQ
formula:UEb_NdBI8RYW4w2liadCWg
193819d443fbf6f.png
1938224b3d16736.png
193822d0a294363.png
193822517829836.png
19381b61ea714a5.png
1938250367ecfe7.png
193d27565bc1e49.png
193824e0c5efc52.png
1938234ac9974eb.png
19381cb680845c4.png
193822ca85be98b.png
formula:ZTOlaBDvSjUyr1AgzQ77iA
193814907fc4a08.png
193814942ee32be.png
19381082320a22b.png
1938109c9fbb3d9.png
193811c5127e6d0.png
193811a03bac859.png
1938121348ac685.png
193812bd5bda577.png
19382599463147c.png
1938259a4749fad.png
formula:99O3K4c5DIWaMZ31cwiSBEeC_eO6wHsGBUTwAfAOWfk5zudFV4apDXKYP-HH0SnYkwWRLD0vco-K_gs92d9iag
1938250b557cb39.png
1938250d727d022.png
1938250f5c0f770.png
19382510c720964.png'''
def identity(url):
 u=urlparse(url)
 return 'formula:'+parse_qs(u.query).get('latex',[''])[0] if 'formulas' in u.path else u.path.split('/')[-1]
def main():
 http={x['url']:x for x in json.loads((OUT/'media_http_results.json').read_text())['results']}
 by_sha={}
 root=OUT.parents[1]
 for cache in [root/'repair-tools/输出_私人文件/assets/index.json',root/'admin-capture/media-audit.json']:
  value=json.loads(cache.read_text())
  entries=[dict(v,url=k) for k,v in value.items()] if isinstance(value,dict) else value
  for entry in entries:by_sha.setdefault(entry['sha256'],set()).add(entry['url'])
 total=collections.Counter();decoded={}
 for folder in sorted(OUT.glob('national_*')):
  manifest=json.loads((folder/'media_manifest.json').read_text());results=[]
  browser_ids=set((ADMIN if 'admin' in folder.name else CITY).splitlines()) if folder.name.endswith('2025') else set()
  for item in manifest['media']:
   url=item['url'];r={'mediaId':item['mediaId'],'references':item['references']}
   if url.startswith('data:image/'):
    try:
     if url not in decoded:
      data=base64.b64decode(url.split(',',1)[1],validate=True)
      with Image.open(io.BytesIO(data)) as im: size=im.size;fmt=im.format;im.verify()
      with Image.open(io.BytesIO(data)) as im: im.load()
      decoded[url]={'status':'embedded_image_verified','bytes':len(data),'width':size[0],'height':size[1],'format':fmt,'sha256':hashlib.sha256(data).hexdigest()}
     r.update(decoded[url])
     item['originalSourceURLs']=sorted(by_sha.get(r['sha256'],[]))
     r['originalSourceURLs']=item['originalSourceURLs']
     item['resourceKind']='formula_image' if any('formulas' in u for u in item['originalSourceURLs']) else 'image'
    except Exception as e:r.update(status='embedded_image_invalid',error=str(e))
   else:
    r.update(url=url,httpCheck={k:v for k,v in http[url].items() if k not in ('references','url','mediaId')})
    ident=identity(url);r['resourceIdentity']=ident
    item['resourceKind']='formula_image' if ident.startswith('formula:') else 'image'
    r['browserCheck']={'status':'same_resource_path_loaded' if ident in browser_ids else 'not_observed','matching':'image filename / formula token, independent of CDN hostname','sourcePage':'2025_admin_source.json' if 'admin' in folder.name else '2025_city_source.json'}
    r['status']='browser_resource_verified' if ident in browser_ids else http[url]['status']
   total[r['status']]+=1;results.append(r)
  counts=dict(collections.Counter(r['status'] for r in results))
  audit={'paper':manifest['paper'],'checkedAt':'2026-10-15','resourceCounts':counts,'results':results,
    'scope':'Embedded PNGs decoded and verified locally; HTTP signatures checked; browser observed complete=true and naturalWidth>0 on original 2025 pages. Browser evidence is original page rendering, not the user site embedding environment.',
    'browserPageElements':35 if folder.name=='national_admin_2025' else 73 if folder.name=='national_city_2025' else None,
    'urlPolicy':'Original URL/data-URI unchanged; current source page CDN hostname may differ.'}
  (folder/'media_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
  (folder/'media_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
  (folder/'formula_references.json').write_text(json.dumps({'paper':manifest['paper'],'resources':[x for x in manifest['media'] if x.get('resourceKind')=='formula_image'],'note':'Formula images are preserved as original images; no OCR replacement of equations.'},ensure_ascii=False,indent=2))
  print(folder.name,counts)
 (OUT/'media_summary.json').write_text(json.dumps({'distinctResources':len(http),'uniqueEmbeddedImagesVerified':len(decoded),'perPaperResources':dict(total),'httpResults':dict(collections.Counter(x['status'] for x in http.values() if not x['url'].startswith('data:'))),'note':'HTTP network_error indicates timeout, not proof of an invalid image; browser source-page rendering verified matching resource identities.'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
