#!/usr/bin/env python3
"""Inspect public source pages, links and stated permissions, without exporting questions."""
import concurrent.futures,hashlib,json,re
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urljoin
OUT=Path(__file__).resolve().parents[1]
SOURCES=[
 ('national_2022_2024','https://www.chinagwy.org/index.php?c=article&m=view&tid=670814'),
 ('national_2024_university','https://xxgcxy.ztbu.edu.cn/2024_11/05_17/content-58247.html'),
 ('zhejiang_2022_2024','https://www.chinagwy.net/zjsk/317178.jhtml'),
 ('national_2022_download','https://bj.huatu.com/2022/1005/1135965.html'),
 ('national_2023','https://www.xiaomaigongkao.com/QuestionNew/paperList/year/2023.html'),
 ('jiangsu_2022','https://www.kkgwy.com/stk/js/14747.html'),
 ('jiangsu_2023','https://www.kkgwy.com/stk/js/14745.html'),
 ('jiangsu_2024','https://szrmjy.com/nd.jsp?id=817'),
 ('jiangsu_2025','https://www.xingguanggongkao.com/XingQuestion/paperList/subject_id/2/area_id/331/year/2025.html'),
 ('jiangsu_2026','https://iget100.com/gongkao/shengkao/jiangsu/2026'),
 ('zhejiang_2025','https://www.xingguanggongkao.com/XingQuestion/paperList/subject_id/2/area_id/332/year/2025.html'),
 ('zhejiang_2026','https://iget100.com/gongkao/shengkao/zhejiang/2026'),
 ('zhejiang_2022_B','https://max.book118.com/html/2022/1105/5322213301010013.shtm'),
 ('jiangsu_official_2024','https://jshrss.jiangsu.gov.cn/col/col89605/index.html'),
 ('zhejiang_official_2022','https://www.zjzzgz.gov.cn/art/2022/6/12/art_1413011_58890982.html'),
 ('github_corpus','https://api.github.com/repos/ERRRC/xingcezhenti'),
 ('github_pdf_collection','https://api.github.com/repos/Yaoyuan-Zhang319/AdministrativeAptitudeTest'),
]
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.parts=[];self.current=None;self.title=[];self.in_title=False
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='title':self.in_title=True
  if t=='a' and a.get('href'):self.current={'href':a['href'],'text':''}
 def handle_data(self,s):
  self.parts.append(s)
  if self.in_title:self.title.append(s)
  if self.current:self.current['text']+=s
 def handle_endtag(self,t):
  if t=='title':self.in_title=False
  if t=='a' and self.current:self.links.append(self.current);self.current=None
def inspect(item):
 key,url=item;r={'key':key,'url':url,'checkedAt':'2026-10-15','downloadPermission':'unconfirmed','bulkConversionPermission':'unconfirmed'}
 try:
  req=Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urlopen(req,timeout=18) as f:
   b=f.read(8000000);r.update(httpStatus=f.status,finalUrl=f.url,bytesRead=len(b),sha256=hashlib.sha256(b).hexdigest())
   charset=f.headers.get_content_charset() or 'utf-8'
   meta=re.search(br'charset=[\"\']?([A-Za-z0-9_-]+)',b[:6000],re.I)
   if meta: charset=meta.group(1).decode('ascii')
  if 'api.github.com' in url:
   d=json.loads(b);r.update(title=d.get('full_name'),repositoryLicense=d.get('license'),sourceType='public_repository')
   r['finding']='GitHub元数据未声明许可证；公开仓库不自动等于开放数据许可。' if not d.get('license') else '许可证需继续核查是否覆盖题目与解析内容。'
  else:
   parser=Links();parser.feed(b.decode(charset,errors='replace'));text=' '.join(parser.parts)
   r['title']=''.join(parser.title).strip()
   links=[{'title':re.sub(r'\s+',' ',a['text']).strip()[:180],'url':urljoin(r['finalUrl'],a['href'])} for a in parser.links]
   r['attachments']=[a for a in links if re.search(r'\.(pdf|docx?|zip)(?:[?#]|$)|downloadPDF',a['url'],re.I)]
   r['examLinks']=[a for a in links if re.search('202[2-6]',a['title']) and re.search('行测|行政职业|真题|地市|市地|执法',a['title'])][:70]
   r['permissionSignals']=[s for s in ['未经许可不得转载','版权所有','个人学习','不得复制','禁止转载','仅供学习','CC BY','Creative Commons'] if s in text]
   r['finding']='已访问页面及附件目录；尚未确认覆盖整卷题目/解析的开放转换许可。'
   if '未经许可不得转载' in text:r['bulkConversionPermission']='restricted_republication';r['finding']='页面明确限制转载；尚未取得整卷转换授权，保留目录及题源链接。'
  r['access']='success'
 except Exception as e:r.update(access='tool_access_failed',errorType=type(e).__name__,error=str(e))
 return r
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:results=list(pool.map(inspect,SOURCES))
 (OUT/'source_catalog.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps([{'key':r['key'],'access':r['access'],'attachments':len(r.get('attachments',[])),'error':r.get('error'),'license':r.get('repositoryLicense'),'signals':r.get('permissionSignals')} for r in results],ensure_ascii=False))
