#!/usr/bin/env python3
"""Turn an authorized paper JSON into the supplied V2 shape and media audit.

Inputs: a V2 paper, the earlier DOM capture shape, or the earlier per-question
paper shape. This program never fetches Fenbi or downloads pictures.
"""
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import urljoin

FIELDS = ('id', 'globalId', 'subject', 'path', 'tags', 'year', 'order',
          'stemHtml', 'optionsHtml', 'answer', 'explanationHtml', 'source',
          'demo', 'rate', 'rateSource', 'totalCount', 'mostWrong')


class Images(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.urls = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'img':
            attr = dict(attrs)
            if attr.get('src'):
                self.urls.append(attr['src'])


def image_urls(markup):
    parser = Images()
    parser.feed(markup or '')
    return parser.urls


def normalize_html(markup):
    return re.sub(r'(<img\b[^>]*?\bsrc\s*=\s*["\'])//', r'\1https://',
                  markup or '', flags=re.I)


def clean_option(markup):
    """Old captures sometimes stored the entire radio-button label."""
    markup = markup or ''
    if '<app-format-html' in markup:
        match = re.search(r'<app-format-html[^>]*>\s*<div[^>]*>(.*?)</div>\s*</app-format-html>',
                          markup, re.I | re.S)
        if match:
            markup = match.group(1)
    return normalize_html(markup)


def convert(raw):
    if set(('name', 'question_count', 'card', 'materials', 'questions')) <= raw.keys():
        paper = {key: raw[key] for key in ('name', 'question_count', 'card', 'materials', 'questions')}
        return paper
    rows = raw['questions']
    title = raw.get('title') or (rows[0].get('paperName') if rows else None) or '未命名试卷'
    year_match = re.search(r'(20\d{2})', title)
    year = int(year_match.group(1)) if year_match else None
    sections = {}
    materials = []
    material_by_key = {}
    questions = []
    for index, q in enumerate(rows, 1):
        number = q.get('number') or q.get('paperNumber') or q.get('order') or index
        key = str(q.get('key') or q.get('globalId') or q.get('id') or f'local:{index}')
        subject = q.get('subject') or '未分类'
        section = sections.setdefault(subject, {'nodeType': 1, 'name': subject, 'children': []})
        material_keys = []
        input_materials = q.get('materials') or []
        if q.get('materialHtml'):
            input_materials = [{'content': q['materialHtml']}]
        for item in input_materials:
            content = normalize_html(item.get('content', ''))
            if not content:
                continue
            identity = item.get('globalId') or hashlib.sha256(content.encode()).hexdigest()[:20]
            identity = str(identity)
            if identity not in material_by_key:
                material_by_key[identity] = content
                materials.append({'globalId': identity, 'content': content})
            elif material_by_key[identity] != content:
                raise ValueError(f'材料 ID {identity} 对应了不同内容')
            material_keys.append(identity)
        section['children'].append({'nodeType': 2, 'key': key, 'materialKeys': material_keys})
        stats = q.get('statistics') or {}
        raw_stats = stats.get('raw') or {}
        subtype = q.get('type')
        keypoints = q.get('keypoints') or []
        keypoint_names = [x.get('name', '') for x in keypoints if isinstance(x, dict) and x.get('name')]
        tags = list(dict.fromkeys(([subtype] if isinstance(subtype, str) and subtype else []) + keypoint_names + (q.get('tags') or [])))
        row = {
            'id': str(q.get('id') or key), 'globalId': key, 'subject': subject,
            # V2 has no standalone type/keypoint column. Retain those source
            # classifications in its existing path/tags fields.
            'path': q.get('path') or ([subject] + ([subtype] if isinstance(subtype, str) and subtype else [])),
            'tags': tags,
            'year': q.get('year') or year, 'order': number,
            'stemHtml': normalize_html(q.get('stemHtml') or q.get('stem') or ''),
            'optionsHtml': [clean_option(x) for x in q.get('optionsHtml', [])],
            'answer': q.get('answer'), 'explanationHtml': normalize_html(q.get('explanationHtml')) or None,
            'source': q.get('source') or title, 'demo': bool(q.get('demo', False)),
            'rate': q.get('rate', q.get('correctRatio')),
            'rateSource': q.get('rateSource') or stats.get('source'),
            'totalCount': q.get('totalCount', raw_stats.get('totalCount')),
            'mostWrong': q.get('mostWrong', raw_stats.get('mostWrongAnswer')),
        }
        questions.append(row)
    return {'name': title, 'question_count': len(questions),
            'card': {'nodeType': 0, 'children': list(sections.values())},
            'materials': materials, 'questions': questions}


def audit(paper):
    rows = paper['questions']
    numbers = [q.get('order') for q in rows]
    errors = []
    if paper['question_count'] != len(rows):
        errors.append('question_count 与 questions 长度不符')
    if len(set(q.get('globalId') for q in rows)) != len(rows):
        errors.append('题目 globalId 重复')
    if numbers != list(range(1, len(rows) + 1)):
        errors.append('题号不从 1 连续递增')
    if any(set(q) != set(FIELDS) for q in rows):
        errors.append('逐题字段与 V2 模板不一致')
    if any(not q.get('stemHtml') or len(q.get('optionsHtml', [])) != 4 for q in rows):
        errors.append('存在缺题干或非四选项题，需人工核对')
    answer_missing = [q['order'] for q in rows if not q.get('answer')]
    explanation_missing = [q['order'] for q in rows if not q.get('explanationHtml')]
    classification_missing = [q['order'] for q in rows if not q.get('path') and not q.get('tags')]
    card_keys = [node['key'] for section in paper['card']['children'] for node in section['children']]
    if card_keys != [q['globalId'] for q in rows]:
        errors.append('card 顺序或 key 与 questions 不一致')
    return {'paper': paper['name'], 'questions': len(rows), 'materials': len(paper['materials']),
            'answerMissing': answer_missing, 'explanationMissing': explanation_missing,
            'classificationMissing': classification_missing,
            'errors': errors, 'dataComplete': not (errors or answer_missing or explanation_missing),
            'siteImportTested': False}


def media(paper):
    by_url = {}
    def add(markup, field, number=None, material=None, option=None):
        for position, url in enumerate(image_urls(markup), 1):
            normalized = urljoin('https:', url) if url.startswith('//') else url
            mid = 'media:' + hashlib.sha256(normalized.encode()).hexdigest()[:20]
            record = by_url.setdefault(normalized, {'mediaId': mid, 'url': normalized, 'references': []})
            reference = {'question': number, 'field': field, 'imageIndex': position}
            if material is not None:
                reference['materialId'] = material
            if option is not None:
                reference['optionIndex'] = option
            record['references'].append(reference)
    for q in paper['questions']:
        add(q.get('stemHtml'), 'stemHtml', q['order'])
        for i, option in enumerate(q.get('optionsHtml', [])):
            add(option, 'optionsHtml', q['order'], option=i)
        add(q.get('explanationHtml'), 'explanationHtml', q['order'])
    # Material references are expanded to every question using that material.
    users = {}
    for section in paper['card']['children']:
        for node in section['children']:
            users[node['key']] = node.get('materialKeys', [])
    by_key = {q['globalId']: q['order'] for q in paper['questions']}
    material_html = {m['globalId']: m.get('content', '') for m in paper['materials']}
    for key, ids in users.items():
        for mid in ids:
            add(material_html.get(mid, ''), 'materials.content', by_key.get(key), mid)
    records = sorted(by_url.values(), key=lambda r: r['mediaId'])
    return {'paper': paper['name'], 'media': records, 'resourceCount': len(records),
            'referenceCount': sum(len(r['references']) for r in records)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='有使用权限的 JSON 原卷')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    raw = json.loads(args.source.read_text(encoding='utf-8-sig'))
    paper = convert(raw)
    report = audit(paper)
    manifest = media(paper)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, obj in [('paper_v2.json', paper), ('media_manifest.json', manifest),
                      ('media_audit.json', {'paper': paper['name'], 'status': 'unchecked',
                                            'note': '仅建立索引；尚未进行网络及浏览器加载检查',
                                            'results': []}), ('audit.json', report)]:
        (args.out / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'out': str(args.out), 'questions': report['questions'],
                      'resources': manifest['resourceCount'], 'dataComplete': report['dataComplete'],
                      'answerMissing': len(report['answerMissing']), 'errors': report['errors']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
