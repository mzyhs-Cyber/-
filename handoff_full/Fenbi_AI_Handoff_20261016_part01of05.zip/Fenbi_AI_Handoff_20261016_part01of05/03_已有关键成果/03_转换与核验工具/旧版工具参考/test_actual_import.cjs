const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const base=path.resolve(__dirname,'..');
const site=path.resolve(base,'tools/site_importer_reference.html');
const html=fs.readFileSync(site,'utf8');
const script=html.split('<script>')[1].split('</script>')[0].split('\nbootstrap();')[0];
const element=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},style:{},querySelectorAll:()=>[]});
function make(){
 const box={performance:{now:()=>0},window:{addEventListener(){},scrollTo(){}},document:{getElementById:()=>element(),addEventListener(){},querySelectorAll:()=>[],hidden:false},setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},console,structuredClone,localStorage:{getItem:()=>null,setItem(){}},navigator:{}};
 vm.createContext(box);vm.runInContext(script,box);
 vm.runInContext('repoPut=async()=>true;APP.bank=[];APP.sessions=[{id:"existing-session",finished:true,answers:{}}];setMeta=()=>{};setView=()=>{};toast=()=>{};',box);
 return box;
}
async function attempt(box,file){
 box.file={name:path.basename(file),text:async()=>fs.readFileSync(file,'utf8')};
 const rows=await vm.runInContext('parseQuestionFile(file)',box); box.items=rows;
 const result=await vm.runInContext('importQuestions(items)',box);
 return {result,parsed:rows.length,bankSize:vm.runInContext('APP.bank.length',box)};
}
(async()=>{
 const reports=[];
 for(const name of fs.readdirSync(base).filter(x=>x.startsWith('national_')).sort()){
  const dir=path.join(base,name),complete=name.endsWith('2026');
  const direct=await attempt(make(),path.join(dir,'paper_v2.json'));
  const b=make(),adapted=await attempt(b,path.join(dir,complete?'site_import.json':'site_import_pending.json'));
  assert.equal(adapted.parsed,130);
  assert.equal(adapted.result.added,complete?130:0);
  assert.equal(adapted.result.invalid,complete?0:130);
  let repeat=null;
  if(complete){
   repeat=await attempt(b,path.join(dir,'site_import.json'));
   assert.equal(repeat.result.added,0);assert.equal(repeat.result.duplicate,130);
   const source=JSON.parse(fs.readFileSync(path.join(dir,'site_import.json'),'utf8')).questions;
   const saved=vm.runInContext('APP.bank',b);
   for(let i=0;i<130;i++){
    for(const field of ['id','globalId','answer','stemHtml','optionsHtml','explanationHtml'])assert.equal(JSON.stringify(saved[i][field]),JSON.stringify(source[i][field]));
    if(source[i].materials.length)assert.equal(saved[i].materialHtml,source[i].materials.map(m=>m.content||'').join('<hr>'));
   }
  }
  assert.equal(vm.runInContext('APP.sessions[0].id',b),'existing-session');
  const report={paper:name,siteSource:'batch-workflow/site-preview/index.html',testMode:'actual site JS in isolated Node VM; storage stubbed, no live user data changed',directV2:direct,adapted,repeat,contentAndIdsPreserved:complete,historicalSessionUnchanged:true,browserUITested:false};
  fs.writeFileSync(path.join(dir,'import_compatibility.json'),JSON.stringify(report,null,2));reports.push(report);
 }
 const b=make();
 const first=await attempt(b,path.join(base,'national_city_2026/site_import.json'));
 const second=await attempt(b,path.join(base,'national_admin_2026/site_import.json'));
 assert.equal(first.result.added,130);assert.equal(second.result.added,51);assert.equal(second.result.conflicts,0);
 assert.equal(vm.runInContext('APP.bank.length',b),181);
 assert.deepEqual(Array.from(vm.runInContext('multiPapers().map(p=>p.entries.length).sort()',b)),[130,130]);
 const combined={uniqueQuestions:181,paperSizes:[130,130],first:first.result,second:second.result,sharedQuestions:79};
 fs.writeFileSync(path.join(base,'import_compatibility_summary.json'),JSON.stringify({reports,combined},null,2));
 console.log(JSON.stringify({passed:true,combined,reports:reports.map(r=>({paper:r.paper,directV2:r.directV2.result,adapted:r.adapted.result}))}));
})().catch(e=>{console.error(e);process.exitCode=1});
