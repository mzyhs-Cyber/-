# 粉笔题库采集器 V2

## 安装

```bash
pip install -r requirements.txt
playwright install chromium
```

如果本机有 Chrome，程序会优先使用已安装 Chrome。

## 运行

```bash
python fenbi_crawler_v2.py
```

首次运行会打开浏览器。手动登录粉笔后，在终端按 Enter。
之后程序会使用持久化浏览器状态，减少重复登录操作。

## 三种模式

1. 当前解析页：采一套
2. 当前分类：批量采集
3. 当前页面能识别的全部分类

## 输出

`fenbi_output/分类/试卷名/`

- `questions.json`：结构化逐题数据
- `questions.xlsx`：单卷 Excel
- `images/`：下载的图片
- `checkpoint.json`：断点记录

## 自动交卷

`AUTO_SUBMIT_BLANK = True`

已默认开启自动交卷。进入尚未完成/尚未进入解析页的目标试卷后，程序会自动点击“交卷/提交”，
再进入解析页抓取题目、答案、正确率、解析、考点、来源和图片，从而尽量减少人工点击。

如果当前页面找不到可用的“交卷/提交”按钮，程序会跳过该套试卷并写入日志，不会伪造结果。

## 重要说明

这是基于网页正常访问和 DOM 提取的版本，不包含绕过验证码、会员权限、登录限制等逻辑。
