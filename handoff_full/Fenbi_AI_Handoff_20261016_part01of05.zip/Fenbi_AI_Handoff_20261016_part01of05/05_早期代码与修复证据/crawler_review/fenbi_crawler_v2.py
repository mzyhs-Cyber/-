
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from openpyxl import Workbook, load_workbook
from playwright.async_api import (
    BrowserContext,
    Locator,
    Page,
    TimeoutError as PlaywrightTimeoutError,
    async_playwright,
)

# ============================================================
# 粉笔题库采集器 V2
# 仅使用浏览器正常访问页面，不绕过登录、验证码、会员/权限控制。
#
# 默认流程：
# 1. 打开 Chrome 持久化用户目录
# 2. 用户手动登录粉笔并打开“历年试卷/目标试卷”页面
# 3. 按 Enter
# 4. 选择：
#    1 = 采集当前打开的一套解析页
#    2 = 采集当前分类下的试卷
#    3 = 自动遍历当前页面能看到的分类
#
# 自动交卷已明确开启：进入尚未做过的试卷时，程序会自动点击“交卷/提交”，
# 再进入解析页采集数据，以减少人工操作。
# 仅适用于你本人正常登录且有权访问的试题。
# ============================================================

START_URL = "https://www.fenbi.com/spa/tiku/guide/realTest/xingce/xingce"

OUTPUT_DIR = Path("fenbi_output")
PROFILE_DIR = Path("fenbi_browser_profile")

HEADLESS = False
AUTO_SUBMIT_BLANK = True

# 并发默认关闭：题库采集优先保证完整性和稳定性。
MAX_PARALLEL = 1

NAV_TIMEOUT = 60_000
ELEMENT_TIMEOUT = 30_000
RETRIES = 3
LIST_SETTLE_MS = 1500
BETWEEN_PAPERS_MS = 1800
BETWEEN_PAGES_MS = 1200

# 你给出的解析页结构对应的核心选择器。
# 代码优先使用相对定位，不使用 div[16] / div[24] 之类的绝对题号路径。
SELECTORS = {
    "question_root": "app-ti, .ti",
    "question_container": "app-question-choice, .ti-container",
    "stem": "app-question-choice article, .ti-content, article",
    "options": (
        "app-choice-radio ul li label p, "
        "app-choice-checkbox ul li label p, "
        ".choice-radio-label, .choice-checkbox-label"
    ),
    "answer": (
        "app-solution-overall div:nth-child(1) span:first-child, "
        ".correct-answer, .overall-item"
    ),
    "accuracy": (
        "app-solution-overall div:nth-child(3) span:first-child, "
        ".right-rate, .correct-rate, [class*='right-rate'], [class*='correct-rate']"
    ),
    "analysis": (
        "app-result-common section:nth-child(2), "
        ".solution-analysis, [class*='solution-analysis']"
    ),
    "keypoint": (
        "app-result-common section:nth-child(3), "
        ".solution-keypoint, [class*='keypoint']"
    ),
    "source": (
        "app-result-common section:nth-child(4), "
        ".solution-source, [class*='source']"
    ),
    "paper_item": "div.paper-item, .paper-item",
    "filter_item": "span.categories-item, .categories-item",
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler("fenbi_crawler.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("fenbi_v2")


@dataclass
class CrawlResult:
    status: str
    title: str
    path: str = ""
    questions: int = 0
    images: int = 0
    message: str = ""


def safe_filename(text: str, fallback: str = "未命名") -> str:
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", text or "")
    text = re.sub(r"\s+", " ", text).strip()
    return text[:160] or fallback


def clean_text(text: Optional[str]) -> str:
    if not text:
        return ""
    text = re.sub(r"\u00a0", " ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def normalize_url(url: str, base_url: str) -> str:
    if not url:
        return ""
    url = url.strip()
    if url.startswith("//"):
        return "https:" + url
    return urljoin(base_url, url)


def question_number_from_text(text: str) -> Optional[int]:
    """
    尝试从题目前部识别显式题号。
    识别不到时，由主流程按“实际题目节点顺序”编号。
    """
    head = clean_text(text)[:120]
    patterns = [
        r"^\s*(\d{1,3})\s*[、．.\)]",
        r"^\s*第\s*(\d{1,3})\s*题",
        r"^\s*(\d{1,3})\s+",
    ]
    for p in patterns:
        m = re.search(p, head)
        if m:
            return int(m.group(1))
    return None


def infer_subtype(text: str, keypoints: list[str]) -> tuple[str, str]:
    """
    只依据页面中实际出现的文字做轻量识别。
    如果没有明确证据，则返回“未识别”，不强行猜。
    """
    haystack = " ".join([text, *keypoints])
    known = [
        "逻辑填空",
        "片段阅读",
        "语句表达",
        "语句排序",
        "语句衔接",
        "主旨概括",
        "意图判断",
        "细节判断",
        "定义判断",
        "类比推理",
        "图形推理",
        "逻辑判断",
        "分析推理",
        "削弱",
        "加强",
        "假设",
        "解释",
        "真假",
        "数量关系",
        "资料分析",
        "常识判断",
        "法律常识",
        "政治理论",
        "一拖二",
        "一拖三",
    ]
    for item in known:
        if item in haystack:
            return item, "页面文字/考点明确出现"
    return "未识别", "页面未提供明确细分标签"


async def first_inner_text(locator: Locator, timeout: int = 2500) -> str:
    try:
        if await locator.count() == 0:
            return ""
        return clean_text(await locator.first.inner_text(timeout=timeout))
    except Exception:
        return ""


async def rich_html_and_images(locator: Locator, page: Page) -> tuple[str, list[str]]:
    """
    提取富文本 HTML，同时找出图片 URL。
    保留 <img>，以便后续下载。
    """
    if await locator.count() == 0:
        return "", []

    try:
        html = await locator.first.inner_html(timeout=ELEMENT_TIMEOUT)
    except Exception:
        return "", []

    soup = BeautifulSoup(html, "html.parser")
    urls: list[str] = []

    for img in soup.find_all("img"):
        raw = (
            img.get("src")
            or img.get("data-src")
            or img.get("data-original")
            or img.get("data-lazy-src")
            or ""
        )
        if raw:
            full = normalize_url(raw, page.url)
            img["src"] = full
            urls.append(full)

    # 去除明显无关脚本/样式
    for tag in soup.find_all(["script", "style", "noscript"]):
        tag.decompose()

    return soup.decode_contents().strip(), list(dict.fromkeys(urls))


async def extract_section_html(container: Locator, selector: str, page: Page) -> tuple[str, list[str]]:
    loc = container.locator(selector)
    if await loc.count() == 0:
        return "", []
    return await rich_html_and_images(loc.first, page)


async def extract_answer(container: Locator) -> str:
    # 首选：与你提供的 app-solution-overall/div/div[1]/span[1] 对应。
    selectors = [
        "app-solution-overall div:nth-child(1) span:first-child",
        ".correct-answer",
        ".overall-item",
    ]

    for sel in selectors:
        loc = container.locator(sel)
        if await loc.count():
            for i in range(min(await loc.count(), 5)):
                try:
                    text = clean_text(await loc.nth(i).inner_text())
                except Exception:
                    continue
                if not text:
                    continue
                if re.fullmatch(r"[A-D](?:\s*[,、]\s*[A-D])*", text, re.I):
                    return text.upper()
                if "正确答案" in text:
                    m = re.search(r"([A-D](?:\s*[,、]\s*[A-D])*)", text, re.I)
                    if m:
                        return m.group(1).upper()

    # 最后在整个题目容器文本里找“正确答案”
    try:
        text = clean_text(await container.inner_text())
        m = re.search(r"正确答案[：:\s]*([A-D](?:\s*[,、]\s*[A-D])*)", text, re.I)
        if m:
            return m.group(1).upper()
    except Exception:
        pass

    return ""


async def extract_accuracy(container: Locator) -> str:
    selectors = [
        "app-solution-overall div:nth-child(3) span:first-child",
        ".right-rate",
        ".correct-rate",
        "[class*='right-rate']",
        "[class*='correct-rate']",
        "[class*='accuracy']",
    ]

    for sel in selectors:
        loc = container.locator(sel)
        count = await loc.count()
        for i in range(min(count, 5)):
            try:
                text = clean_text(await loc.nth(i).inner_text())
            except Exception:
                continue
            if re.search(r"\d+(?:\.\d+)?\s*%", text):
                return text

    # 兜底：只在“正确率/正确”附近找百分比，避免把其他百分比误抓。
    try:
        text = clean_text(await container.inner_text())
        m = re.search(
            r"(?:正确率|正确)[：:\s]*(\d+(?:\.\d+)?\s*%)",
            text,
            re.I,
        )
        if m:
            return m.group(1)
    except Exception:
        pass

    return ""


async def extract_keypoints(container: Locator) -> list[str]:
    loc = container.locator(SELECTORS["keypoint"])
    if await loc.count() == 0:
        return []

    text = clean_text(await loc.first.inner_text())
    if not text:
        return []

    # 兼容“考点A / 考点B”以及普通一行文本。
    parts = [
        clean_text(x)
        for x in re.split(r"[\n\r]+|[；;]", text)
        if clean_text(x)
    ]
    return list(dict.fromkeys(parts))


async def extract_one_question(
    container: Locator,
    question_no: int,
    page: Page,
    group_label: str = "",
) -> dict[str, Any]:
    stem_loc = container.locator(SELECTORS["stem"]).first
    stem_html, stem_images = await rich_html_and_images(stem_loc, page)

    # 如果 article 没有命中，保留容器文本作为兜底。
    stem_text = clean_text(
        await first_inner_text(stem_loc)
    )
    if not stem_text:
        try:
            stem_text = clean_text(await container.inner_text())
        except Exception:
            stem_text = ""

    options: list[dict[str, Any]] = []
    opt_loc = container.locator(SELECTORS["options"])
    count = await opt_loc.count()

    # 同一题中可能存在多个 selector 命中同一节点，去重。
    seen_option_text: set[str] = set()
    for i in range(count):
        try:
            loc = opt_loc.nth(i)
            html, imgs = await rich_html_and_images(loc, page)
            text = clean_text(await loc.inner_text())
        except Exception:
            continue

        if not text and not html:
            continue

        # 如果同一个 DOM 节点被多个 selector 重复命中，去重。
        dedupe_key = re.sub(r"\s+", " ", text)
        if dedupe_key in seen_option_text:
            continue
        seen_option_text.add(dedupe_key)

        letter = chr(ord("A") + len(options))
        options.append(
            {
                "key": letter,
                "text": text,
                "html": html,
                "images": imgs,
            }
        )

    analysis_html, analysis_images = await extract_section_html(
        container, SELECTORS["analysis"], page
    )
    keypoints = await extract_keypoints(container)
    source_html, source_images = await extract_section_html(
        container, SELECTORS["source"], page
    )

    # 正确率单独抓取
    accuracy = await extract_accuracy(container)
    answer = await extract_answer(container)

    subtype, subtype_basis = infer_subtype(
        group_label,
        keypoints,
    )

    all_images = list(
        dict.fromkeys(
            stem_images
            + [u for x in options for u in x["images"]]
            + analysis_images
            + source_images
        )
    )

    return {
        "question_no": question_no,
        "question_type": group_label or "未识别",
        "subtype": subtype,
        "subtype_basis": subtype_basis,
        "stem": stem_text,
        "stem_html": stem_html,
        "options": options,
        "answer": answer,
        "accuracy": accuracy,
        "analysis_html": analysis_html,
        "keypoints": keypoints,
        "source_html": source_html,
        "images": all_images,
        "image_count": len(all_images),
    }


async def get_question_containers(page: Page) -> list[Locator]:
    """
    以 app-ti 为主，而不是 div[16] / div[24]。
    优先寻找页面中实际包含 app-question-choice 的题目节点。
    """
    roots = page.locator("app-ti")
    n = await roots.count()
    result: list[Locator] = []

    for i in range(n):
        root = roots.nth(i)
        if await root.locator("app-question-choice, .ti-container").count():
            result.append(root)

    if result:
        return result

    # 兼容旧版 DOM
    roots = page.locator(".ti")
    n = await roots.count()
    for i in range(n):
        root = roots.nth(i)
        if await root.locator("app-question-choice, .ti-container").count():
            result.append(root)

    return result


async def extract_exam_data(page: Page) -> tuple[dict[str, Any], int]:
    await page.wait_for_timeout(LIST_SETTLE_MS)

    # 先尝试等待题目容器。
    try:
        await page.wait_for_selector(
            "app-ti app-question-choice, .ti .ti-container",
            timeout=ELEMENT_TIMEOUT,
        )
    except PlaywrightTimeoutError:
        pass

    containers = await get_question_containers(page)
    if not containers:
        raise RuntimeError("没有找到题目容器：请检查当前是否处于解析页。")

    # 页面级题型/章节标签：优先采用你提供的 app-tis 第一块信息，
    # 再退回常见 class。
    group_label = ""
    for sel in [
        "app-tis > div:first-child > div:first-child",
        ".title-type-name",
        ".chapter-name",
        ".categories-item.active",
    ]:
        loc = page.locator(sel)
        if await loc.count():
            group_label = await first_inner_text(loc)
            if group_label:
                break

    questions: list[dict[str, Any]] = []
    material_groups: list[dict[str, Any]] = []

    # 用实际题目节点顺序编号，不把 div[16] 当题号。
    for idx, container in enumerate(containers, start=1):
        try:
            data = await extract_one_question(
                container,
                question_no=idx,
                page=page,
                group_label=group_label,
            )
            questions.append(data)
        except Exception as exc:
            logger.exception("第 %s 题提取失败: %s", idx, exc)

    if not questions:
        raise RuntimeError("题目节点存在，但没有成功提取任何题目。")

    # 检测材料题：如果题目节点附近存在材料区域，保留材料 HTML/图片。
    for i, container in enumerate(containers, start=1):
        try:
            mat_loc = container.locator(
                ".materials-container, .resizable-container"
            )
            if await mat_loc.count():
                html, imgs = await rich_html_and_images(mat_loc.first, page)
                if html:
                    material_groups.append(
                        {
                            "anchor_question_no": i,
                            "html": html,
                            "images": imgs,
                        }
                    )
        except Exception:
            pass

    title = ""
    for sel in [
        ".paper-title",
        ".exam-title",
        ".solution-title",
        "h1",
        "title",
    ]:
        loc = page.locator(sel)
        if await loc.count():
            title = await first_inner_text(loc, timeout=1500)
            if title:
                break

    if not title:
        title = "未命名试卷"

    result = {
        "schema_version": "fenbi-question-v2",
        "paper_title": title,
        "page_url": page.url,
        "question_count": len(questions),
        "group_label": group_label,
        "questions": questions,
        "materials": material_groups,
    }

    return result, len(questions)


async def download_one_image(
    context: BrowserContext,
    page: Page,
    url: str,
    image_dir: Path,
) -> Optional[str]:
    if not url:
        return None

    image_dir.mkdir(parents=True, exist_ok=True)

    # data:image/... 直接保存
    if url.startswith("data:image/"):
        try:
            header, encoded = url.split(",", 1)
            ext = "png"
            if "jpeg" in header:
                ext = "jpg"
            elif "webp" in header:
                ext = "webp"
            name = hashlib.sha1(url.encode("utf-8")).hexdigest()[:20] + "." + ext
            path = image_dir / name
            if not path.exists():
                path.write_bytes(base64.b64decode(encoded))
            return str(path.relative_to(OUTPUT_DIR)).replace("\\", "/")
        except Exception:
            return None

    if url.startswith("blob:"):
        # blob URL 不能直接通过 requests 下载。
        # 这里只返回空值；页面截图兜底可在后续按 DOM 元素补。
        return None

    if not url.startswith(("http://", "https://")):
        return None

    digest = hashlib.sha1(url.encode("utf-8")).hexdigest()[:20]
    suffix = Path(urlparse(url).path).suffix.lower()
    if suffix not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"}:
        suffix = ".png"

    path = image_dir / f"{digest}{suffix}"

    if path.exists() and path.stat().st_size > 0:
        return str(path.relative_to(OUTPUT_DIR)).replace("\\", "/")

    try:
        response = await context.request.get(
            url,
            timeout=30_000,
            fail_on_status_code=False,
        )
        if response.ok:
            body = await response.body()
            if body:
                path.write_bytes(body)
                return str(path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    except Exception as exc:
        logger.warning("图片下载失败 %s: %s", url, exc)

    return None


def replace_image_urls_in_html(html: str, mapping: dict[str, str]) -> str:
    if not html:
        return html
    for src, local in mapping.items():
        html = html.replace(src, local)
    return html


async def localize_images(
    context: BrowserContext,
    page: Page,
    data: dict[str, Any],
    image_dir: Path,
) -> int:
    urls: set[str] = set()

    for q in data["questions"]:
        urls.update(q.get("images", []))
    for mat in data.get("materials", []):
        urls.update(mat.get("images", []))

    mapping: dict[str, str] = {}

    for url in sorted(urls):
        local = await download_one_image(context, page, url, image_dir)
        if local:
            mapping[url] = local

    for q in data["questions"]:
        q["stem_html"] = replace_image_urls_in_html(
            q.get("stem_html", ""), mapping
        )
        q["analysis_html"] = replace_image_urls_in_html(
            q.get("analysis_html", ""), mapping
        )
        q["source_html"] = replace_image_urls_in_html(
            q.get("source_html", ""), mapping
        )

        for opt in q.get("options", []):
            opt["html"] = replace_image_urls_in_html(
                opt.get("html", ""), mapping
            )

        q["images_local"] = [
            {"source": u, "path": mapping.get(u, "")}
            for u in q.get("images", [])
        ]

    for mat in data.get("materials", []):
        mat["html"] = replace_image_urls_in_html(
            mat.get("html", ""), mapping
        )
        mat["images_local"] = [
            {"source": u, "path": mapping.get(u, "")}
            for u in mat.get("images", [])
        ]

    return len(mapping)


def flatten_for_excel(data: dict[str, Any], filter_name: str) -> list[list[Any]]:
    rows = []
    for q in data["questions"]:
        opts = q.get("options", [])
        option_text = {x["key"]: x.get("text", "") for x in opts}
        rows.append(
            [
                data.get("paper_title", ""),
                filter_name,
                q.get("question_no", ""),
                q.get("question_type", ""),
                q.get("subtype", ""),
                q.get("stem", ""),
                option_text.get("A", ""),
                option_text.get("B", ""),
                option_text.get("C", ""),
                option_text.get("D", ""),
                q.get("answer", ""),
                q.get("accuracy", ""),
                "\n".join(q.get("keypoints", [])),
                BeautifulSoup(
                    q.get("analysis_html", ""), "html.parser"
                ).get_text(" ", strip=True),
                BeautifulSoup(
                    q.get("source_html", ""), "html.parser"
                ).get_text(" ", strip=True),
                json.dumps(
                    q.get("images_local", []),
                    ensure_ascii=False,
                ),
            ]
        )
    return rows


def append_excel(
    path: Path,
    data: dict[str, Any],
    filter_name: str,
) -> None:
    headers = [
        "试卷名称",
        "分类",
        "题号",
        "大题型",
        "细分题型",
        "题目",
        "A",
        "B",
        "C",
        "D",
        "答案",
        "正确率",
        "考点",
        "解析",
        "来源",
        "图片",
    ]

    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists():
        wb = load_workbook(path)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "题库"
        ws.append(headers)

    existing_keys = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] and row[2]:
            existing_keys.add((str(row[0]), str(row[2])))

    for row in flatten_for_excel(data, filter_name):
        key = (str(row[0]), str(row[2]))
        if key not in existing_keys:
            ws.append(row)
            existing_keys.add(key)

    # 基础可读性
    widths = {
        "A": 34, "B": 18, "C": 8, "D": 18, "E": 18,
        "F": 55, "G": 30, "H": 30, "I": 30, "J": 30,
        "K": 10, "L": 10, "M": 28, "N": 55, "O": 30, "P": 40,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    wb.save(path)


def checkpoint_path() -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR / "checkpoint.json"


def load_checkpoint() -> dict[str, Any]:
    path = checkpoint_path()
    if not path.exists():
        return {"papers": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"papers": {}}


def save_checkpoint(cp: dict[str, Any]) -> None:
    checkpoint_path().write_text(
        json.dumps(cp, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )



def validate_question(q: dict[str, Any]) -> dict[str, Any]:
    checks = {
        "stem": bool(clean_text(q.get("stem", ""))),
        "options": len(q.get("options", [])) >= 2,
        "answer": bool(clean_text(q.get("answer", ""))),
        "accuracy": bool(clean_text(q.get("accuracy", ""))),
        "analysis": bool(clean_text(BeautifulSoup(
            q.get("analysis_html", ""), "html.parser"
        ).get_text(" ", strip=True))),
        "keypoints": bool(q.get("keypoints")),
        "source": bool(clean_text(BeautifulSoup(
            q.get("source_html", ""), "html.parser"
        ).get_text(" ", strip=True))),
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "missing": [k for k, v in checks.items() if not v],
    }


def validate_exam(data: dict[str, Any]) -> dict[str, Any]:
    rows = []
    for q in data.get("questions", []):
        v = validate_question(q)
        rows.append({
            "question_no": q.get("question_no"),
            "ok": v["ok"],
            "missing": v["missing"],
            "image_count": len(q.get("images", [])),
        })

    total = len(rows)
    complete = sum(1 for r in rows if r["ok"])
    return {
        "total_questions": total,
        "complete_questions": complete,
        "incomplete_questions": total - complete,
        "completeness_rate": round(complete / total, 4) if total else 0,
        "questions": rows,
    }


async def save_exam(
    context: BrowserContext,
    page: Page,
    data: dict[str, Any],
    filter_name: str,
) -> CrawlResult:
    title = safe_filename(data.get("paper_title", "未命名试卷"))
    folder = OUTPUT_DIR / safe_filename(filter_name or "未分类") / title
    folder.mkdir(parents=True, exist_ok=True)

    image_dir = folder / "images"
    image_count = await localize_images(
        context, page, data, image_dir
    )

    validation = validate_exam(data)
    data["validation"] = validation

    (folder / "validation.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    json_path = folder / "questions.json"
    json_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 同时生成一份单卷 Excel
    xlsx_path = folder / "questions.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "题目"
    headers = [
        "试卷名称", "分类", "题号", "大题型", "细分题型",
        "题目", "A", "B", "C", "D", "答案", "正确率",
        "考点", "解析", "来源", "图片"
    ]
    ws.append(headers)
    for row in flatten_for_excel(data, filter_name):
        ws.append(row)
    wb.save(xlsx_path)

    return CrawlResult(
        status="success",
        title=title,
        path=str(folder),
        questions=len(data["questions"]),
        images=image_count,
    )


async def is_solution_page(page: Page) -> bool:
    if "/solution/" in page.url:
        return True
    if await page.locator("app-solution, app-solution-overall").count():
        return True
    if await page.locator(".solution-title, .solution-title-container").count():
        return True
    return False


async def submit_blank_if_enabled(page: Page) -> bool:
    if not AUTO_SUBMIT_BLANK:
        return False

    selectors = [
        "div.submit-btn",
        "button.submit-btn",
        "[class*='submit-btn']",
    ]
    submit = None
    for sel in selectors:
        loc = page.locator(sel)
        if await loc.count():
            submit = loc.first
            break

    if submit is None:
        return False

    try:
        await submit.click(timeout=5000)
    except Exception:
        return False

    # 确认按钮
    for sel in [
        "button.btn-submit",
        "button:has-text('确认交卷')",
        "button:has-text('提交')",
    ]:
        loc = page.locator(sel)
        if await loc.count():
            try:
                await loc.first.click(timeout=5000)
                await page.wait_for_timeout(2000)
                return True
            except Exception:
                pass

    return False


async def crawl_current_page(
    context: BrowserContext,
    page: Page,
    filter_name: str = "",
) -> CrawlResult:
    for attempt in range(1, RETRIES + 1):
        try:
            if not await is_solution_page(page):
                submitted = await submit_blank_if_enabled(page)
                if not submitted:
                    return CrawlResult(
                        status="skipped",
                        title="",
                        message=(
                            "当前页面不是解析页，且未找到可用的自动交卷按钮，"
                            "因此跳过本套试卷。"
                        ),
                    )

                await page.wait_for_timeout(2500)

            data, count = await extract_exam_data(page)
            return await save_exam(context, page, data, filter_name)

        except Exception as exc:
            logger.warning(
                "当前试卷第 %s/%s 次尝试失败：%s",
                attempt, RETRIES, exc,
            )
            if attempt < RETRIES:
                await page.wait_for_timeout(1500 * attempt)

    return CrawlResult(
        status="failed",
        title="",
        message="多次尝试仍未成功，请检查日志和页面结构。",
    )


async def get_filter_names(page: Page) -> list[str]:
    loc = page.locator(SELECTORS["filter_item"])
    result = []
    for i in range(await loc.count()):
        try:
            text = clean_text(await loc.nth(i).inner_text())
        except Exception:
            continue
        if text and "推荐" not in text and text not in result:
            result.append(text)
    return result


async def get_paper_items(page: Page) -> list[dict[str, str]]:
    loc = page.locator(SELECTORS["paper_item"])
    result = []

    for i in range(await loc.count()):
        item = loc.nth(i)
        try:
            title = ""
            for sel in [
                "div.item-info-title",
                ".item-info-title",
                ".paper-title",
                "a",
            ]:
                x = item.locator(sel)
                if await x.count():
                    title = clean_text(await x.first.inner_text())
                    if title:
                        break

            href = ""
            links = item.locator("a")
            if await links.count():
                href = await links.first.get_attribute("href") or ""
                href = normalize_url(href, page.url)

            result.append(
                {
                    "title": title or f"Paper_{i + 1}",
                    "href": href,
                    "index": str(i),
                }
            )
        except Exception:
            continue

    return result


async def click_filter(page: Page, filter_name: str) -> bool:
    loc = page.locator(SELECTORS["filter_item"])
    for i in range(await loc.count()):
        item = loc.nth(i)
        try:
            if clean_text(await item.inner_text()) == filter_name:
                await item.click()
                await page.wait_for_timeout(LIST_SETTLE_MS)
                return True
        except Exception:
            continue
    return False


async def crawl_category(
    context: BrowserContext,
    page: Page,
    filter_name: str,
) -> list[CrawlResult]:
    results = []

    if not await click_filter(page, filter_name):
        return [
            CrawlResult(
                status="failed",
                title="",
                message=f"找不到分类：{filter_name}",
            )
        ]

    seen_papers: set[str] = set()
    page_round = 0

    while True:
        page_round += 1
        await page.wait_for_timeout(BETWEEN_PAGES_MS)

        papers = await get_paper_items(page)
        if not papers:
            break

        logger.info(
            "[%s] 第 %s 个列表页发现 %s 套试卷",
            filter_name, page_round, len(papers),
        )

        for paper in papers:
            key = paper["href"] or paper["title"]
            if key in seen_papers:
                continue
            seen_papers.add(key)

            cp = load_checkpoint()
            cp_key = f"{filter_name}|{key}"
            if cp["papers"].get(cp_key, {}).get("status") == "success":
                logger.info("跳过已完成：%s", paper["title"])
                continue

            try:
                # 优先直接打开 href，避免依赖脆弱的 DOM index。
                if paper["href"]:
                    await page.goto(
                        paper["href"],
                        timeout=NAV_TIMEOUT,
                        wait_until="domcontentloaded",
                    )
                else:
                    current = await get_paper_items(page)
                    idx = int(paper["index"])
                    if idx >= len(current):
                        continue
                    await page.locator(SELECTORS["paper_item"]).nth(idx).click()

                await page.wait_for_timeout(1500)
                result = await crawl_current_page(
                    context, page, filter_name
                )
                results.append(result)

                cp = load_checkpoint()
                cp["papers"][cp_key] = {
                    "status": result.status,
                    "title": result.title or paper["title"],
                    "path": result.path,
                    "questions": result.questions,
                    "images": result.images,
                    "message": result.message,
                }
                save_checkpoint(cp)

            except Exception as exc:
                logger.exception("处理试卷失败：%s", paper["title"])
                results.append(
                    CrawlResult(
                        status="failed",
                        title=paper["title"],
                        message=str(exc),
                    )
                )

            finally:
                # 回到分类列表
                try:
                    await page.goto(
                        START_URL,
                        timeout=NAV_TIMEOUT,
                        wait_until="domcontentloaded",
                    )
                    await page.wait_for_timeout(1000)
                    await click_filter(page, filter_name)
                except Exception:
                    pass

                await page.wait_for_timeout(BETWEEN_PAPERS_MS)

        # 尝试下一页；没有则结束。
        next_selectors = [
            "button:has-text('下一页')",
            "a:has-text('下一页')",
            ".pagination-next",
            "[aria-label='Next']",
        ]

        moved = False
        for sel in next_selectors:
            loc = page.locator(sel)
            if await loc.count():
                try:
                    if await loc.first.is_visible():
                        disabled = await loc.first.get_attribute("disabled")
                        cls = await loc.first.get_attribute("class") or ""
                        if disabled is None and "disabled" not in cls:
                            await loc.first.click()
                            await page.wait_for_timeout(BETWEEN_PAGES_MS)
                            moved = True
                            break
                except Exception:
                    pass

        if not moved:
            break

    return results


def print_result(result: CrawlResult) -> None:
    logger.info(
        "结果 | %s | %s | 题目=%s | 图片=%s | %s",
        result.status,
        result.title,
        result.questions,
        result.images,
        result.path or result.message,
    )


async def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    PROFILE_DIR.mkdir(exist_ok=True)

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            str(PROFILE_DIR),
            channel="chrome",
            headless=HEADLESS,
            no_viewport=False,
            viewport={"width": 1440, "height": 900},
        )

        page = context.pages[0] if context.pages else await context.new_page()

        try:
            await page.goto(
                START_URL,
                timeout=NAV_TIMEOUT,
                wait_until="domcontentloaded",
            )
        except Exception as exc:
            logger.warning("打开粉笔页面失败：%s", exc)

        print("\n" + "=" * 60)
        print("粉笔题库采集器 V2")
        print("=" * 60)
        print("请在打开的 Chrome 中手动登录粉笔。")
        print("登录后，打开你有权限访问的目标页面。")
        print("不要关闭这个浏览器窗口。")
        input("\n准备好后，在终端按 Enter 开始：")

        print("\n请选择模式：")
        print("1. 当前页面直接采集（一套解析页）")
        print("2. 当前分类批量采集")
        print("3. 遍历当前页面可识别的全部分类")
        mode = input("输入 1 / 2 / 3：").strip()

        if mode == "1":
            result = await crawl_current_page(context, page)
            print_result(result)

        elif mode == "2":
            filters = await get_filter_names(page)
            print("\n当前可识别分类：")
            for i, name in enumerate(filters, 1):
                print(f"{i}. {name}")

            raw = input("输入分类编号：").strip()
            try:
                idx = int(raw) - 1
                filter_name = filters[idx]
            except Exception:
                print("分类编号无效。")
                await context.close()
                return

            results = await crawl_category(context, page, filter_name)
            for result in results:
                print_result(result)

        elif mode == "3":
            filters = await get_filter_names(page)
            logger.info("发现分类：%s", filters)

            for filter_name in filters:
                logger.info("开始分类：%s", filter_name)
                results = await crawl_category(
                    context, page, filter_name
                )
                for result in results:
                    print_result(result)

        else:
            print("无效模式。")

        print("\n完成。")
        print(f"输出目录：{OUTPUT_DIR.resolve()}")
        print(f"日志：{Path('fenbi_crawler.log').resolve()}")

        await context.close()


if __name__ == "__main__":
    asyncio.run(main())
