from __future__ import annotations
import argparse
import asyncio
import base64
import hashlib
import io
import json
import logging
import re
import time
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from zoneinfo import ZoneInfo
from openpyxl import Workbook
from PIL import Image
from playwright.async_api import async_playwright
from bank_core import VERSION, json_write, media_manifest, parse_question, to_v2, validate_exam
START_URL = 'https://www.fenbi.com/spa/tiku/guide/realTest/xingce/xingce'
PAPER_ITEMS, FILTER_ITEMS = ('.paper-item', '.categories-item')
NEXT_LIST = "button:has-text('下一页'), a:has-text('下一页'), .pagination-next, [aria-label='Next']"
NEXT_QUESTION = "button:has-text('下一题'), a:has-text('下一题'), .next-question"
LOG = logging.getLogger('fenbi')

def now():
    return datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def safe_name(s):
    return re.sub('[<>:"/\\\\|?*\\x00-\\x1f]', '_', s).strip(' .')[:120] or '未命名'

def allowed_page(url):
    parts = urlsplit(url)
    host = parts.hostname or ''
    return not parts.username and (not parts.password) and (parts.scheme == 'https') and (host == 'fenbi.com' or host.endswith('.fenbi.com'))

async def click_next(page, selector):
    for loc in await page.locator(selector).all():
        if await loc.is_visible() and await loc.is_enabled() and (await loc.get_attribute('aria-disabled') != 'true'):
            if 'disabled' not in (await loc.get_attribute('class') or ''):
                await loc.click(timeout=5000)
                await page.wait_for_timeout(1000)
                return True
    return False

async def solution_visible(page):
    return any([await x.is_visible() for x in await page.locator('app-solution-overall, .correct-answer').all()])

async def ensure_solution(page, args, submitted):
    if await solution_visible(page):
        return None
    if not args.auto_submit:
        raise RuntimeError('不是解析页，自动交卷已关闭。请正常打开解析页。')
    key = page.url
    if key in submitted:
        raise RuntimeError('已尝试提交该页面，不重复交卷。')
    if not any([await x.is_visible() for x in await page.locator("app-question-choice, .ti-content, [data-role='stem']").all()]):
        raise RuntimeError('未确认当前是练习题页面，不点击提交按钮。')
    submit = page.locator('div.submit-btn:visible, button.submit-btn:visible')
    if await submit.count() != 1:
        raise RuntimeError('没有唯一可见的交卷按钮，未执行提交。')
    event = {'time': now(), 'url': key, 'kind': 'placeholder_submission', 'status': 'attempted', 'purpose': '自动占位，仅用于取得解析', 'exclude_from_personal_statistics': True}
    submitted[key] = event

    def record(value):
        with (args.output / 'submission_events.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(value, ensure_ascii=False) + '\n')
    record(event)
    await submit.click()
    await page.wait_for_timeout(600)
    if not await solution_visible(page):
        dialogs = page.locator("[role='dialog']:visible, dialog:visible, [class*='dialog']:visible, [class*='modal']:visible, [class*='popup']:visible, app-exam-submit-dialog:visible").filter(has_text=re.compile('交卷|提交试卷|未作答|未答'))
        confirm = dialogs.locator("button:visible, [role='button']:visible, .btn-submit:visible, .confirm-btn:visible, .submit-btn:visible").filter(has_text=re.compile(r'^\s*(确认交卷|确定交卷|提交试卷|确认提交|交卷|提交|确定|确认)\s*$'))
        try:
            await confirm.first.wait_for(state='visible', timeout=8000)
        except Exception:
            pass
        if await confirm.count() == 1:
            await confirm.click()
        else:
            if getattr(args, 'headless', False):
                raise RuntimeError('无法识别交卷确认窗口，请改用有界面模式。')
            while not await solution_visible(page):
                print('请在浏览器里手动完成交卷，看到标准答案和解析后再回来。', flush=True)
                await asyncio.to_thread(input, '完成后按 Enter 继续采集：')
    for _ in range(30):
        if await solution_visible(page):
            event = {**event, 'time': now(), 'status': 'solution_opened'}
            record(event)
            return event
        await page.wait_for_timeout(500)
    raise RuntimeError('提交后未确认解析已打开，未计为采集成功。')
SNAPSHOT_JS = '() => {\n const visible=e=>!!e.getClientRects().length && getComputedStyle(e).visibility!==\'hidden\';\n let roots=[...document.querySelectorAll(\'app-ti\')].filter(visible);\n if(!roots.length) roots=[...document.querySelectorAll(\'.ti\')].filter(visible);\n roots=roots.filter(e=>e.querySelector(\'app-question-choice,.ti-content,[data-role="stem"]\'));\n const cards=[...document.querySelectorAll(\'.answer-card a[href^="#"],.answer-card [data-question-no],a[href^="#title-"]\')]\n   .filter(visible).map(e=>({target:(e.getAttribute(\'href\')||\'\').slice(1),no:e.getAttribute(\'data-question-no\')||e.innerText.trim()}));\n const rows=roots.map(e=>{\n   const heading=e.closest(\'[id^="title-"]\')||e.querySelector(\'[id^="title-"]\');\n   const card=cards.find(c=>c.target && c.target===heading?.id);\n   let material=e.querySelector(\'.materials-container .material-content,app-materials .material-content\');\n   if(!material) {\n     let parent=e.parentElement;\n     for(let i=0;parent && parent!==document.body && i<5;i++,parent=parent.parentElement) {\n       if(parent.matches(\'.resizable-container,.question-group,[data-material-group]\')) {\n         const ms=parent.querySelectorAll(\'.materials-container .material-content\');\n         if(ms.length===1) material=ms[0];\n         break;\n       }\n     }\n   }\n   if(!material && roots.length===1) {\n     const ms=[...document.querySelectorAll(\'app-materials .material-content\')].filter(visible);\n     if(ms.length===1) material=ms[0];\n   }\n   const subject=e.getAttribute(\'data-subject\')||e.closest(\'[data-subject]\')?.getAttribute(\'data-subject\')||\n     e.closest(\'app-tis\')?.querySelector(\'.title-type-name,.chapter-name\')?.innerText||\'\';\n   const raw=e.getAttribute(\'data-question-no\')||card?.no||\'\';\n   return {html:e.outerHTML,order:/^\\d+$/.test(raw.trim())?Number(raw):null,subject:subject.trim(),material:material?.outerHTML||\'\'};\n });\n const counts=[];\n for(const e of [...document.querySelectorAll(\'[data-question-count],.question-count,.total-count,.paper-summary\')].filter(visible)) {\n   const n=e.getAttribute(\'data-question-count\');\n   if(n && /^\\d+$/.test(n)) counts.push(Number(n));\n   for(const m of e.innerText.matchAll(/(?:共|总计|总题数[：:\\s]*)\\s*(\\d+)\\s*题/g)) counts.push(Number(m[1]));\n }\n const titles=[...document.querySelectorAll(\'.paper-title,.exam-title,.solution-title-container .paper-name,h1\')]\n   .filter(visible).map(e=>e.innerText.trim()).filter(Boolean);\n const allMaterials=[...document.querySelectorAll(\'.materials-container .material-content\')]\n   .filter(visible).filter(e=>!e.parentElement.closest(\'.material-content\'));\n return {rows,counts:[...new Set(counts)],title:titles[0]||\'\',\n   unresolvedMaterials:allMaterials.some(e=>!rows.some(r=>r.material===e.outerHTML))};\n}'

async def extract_exam_data(page, expected=None, expected_title=None, max_rounds=300):
    questions, observations, errors, counts, titles, snapshots = ({}, [], set(), set(), set(), {})
    previous, stagnant = (None, 0)
    for _ in range(max_rounds):
        snap = await page.evaluate(SNAPSHOT_JS)
        if snap['title']:
            titles.add(snap['title'])
        counts.update(snap['counts'])
        if snap['unresolvedMaterials']:
            errors.add('unresolved_visible_material')
        for row in snap['rows']:
            snapshot_hash = hashlib.sha256(json.dumps(row, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            snapshots[snapshot_hash] = row
            q = parse_question(row['html'], page.url, row['order'], row['subject'], row['material'])
            identity = q.get('globalId') or 'missing:' + hashlib.sha256(row['html'].encode()).hexdigest()
            prior = questions.get(identity)
            if prior:
                if prior.get('question_no') != q.get('question_no'):
                    errors.add('conflicting_order:' + identity)
                for field in ('stem_html', 'options', 'answer', 'analysis_html', 'materials'):
                    if prior.get(field) and q.get(field) and (prior[field] != q[field]):
                        errors.add('conflicting_' + field + ':' + identity)
                for field, value in q.items():
                    if not prior.get(field) and value:
                        prior[field] = value
            else:
                questions[identity] = q
        observations.append({'visible_questions': len(snap['rows']), 'collected': len(questions)})
        fingerprint = tuple(((k, v.get('answer'), len(v.get('analysis_html', ''))) for k, v in questions.items()))
        stagnant = stagnant + 1 if fingerprint == previous else 0
        previous = fingerprint
        count = expected or (next(iter(counts)) if len(counts) == 1 else None)
        if count and len(questions) == count and all((q.get('answer') and q.get('analysis_html') for q in questions.values())):
            break
        if await click_next(page, NEXT_QUESTION):
            continue
        moved = await page.evaluate("() => {\n          let moved=false;\n          for(const e of [document.scrollingElement,...document.querySelectorAll('app-tis,.right-section,.question-list,.solution-content')]) {\n            if(!e||!e.getClientRects().length) continue;\n            const before=e.scrollTop; e.scrollTop+=Math.max(400,e.clientHeight*0.8);\n            moved ||= e.scrollTop!==before;\n          }\n          return moved;\n        }")
        await page.wait_for_timeout(700)
        if stagnant >= 3 and (not moved):
            break
    else:
        errors.add('collection_round_limit')
    if len(counts) > 1:
        errors.add('ambiguous_expected_count')
    if expected and counts and (counts != {expected}):
        errors.add('expected_count_conflicts_with_page')
    if len(titles) > 1:
        errors.add('conflicting_paper_titles')
    title = next(iter(titles)) if len(titles) == 1 else '未命名试卷'
    if expected_title and title != expected_title:
        errors.add('paper_title_mismatch')
    return {'schema_version': VERSION, 'paper_title': title, 'page_url': page.url, 'expected_count': expected or (next(iter(counts)) if len(counts) == 1 else None), 'questions': list(questions.values()), 'collection_errors': sorted(errors), 'observations': observations, 'captured_at': now(), 'rendered_snapshots': list(snapshots.values())}

async def verify_media(context, v2, folder, download=False):
    manifest, sem = (media_manifest(v2), asyncio.Semaphore(4))

    async def check(src):
        async with sem:
            result = {'checked_at': now(), 'status': 'unchecked'}
            try:
                if src.startswith('data:image/'):
                    header, data = src.split(',', 1)
                    if ';base64' not in header:
                        raise ValueError('unsupported_data_uri')
                    body = base64.b64decode(data, validate=True)
                elif urlsplit(src).scheme in ('https', 'http'):
                    response = await context.request.get(src, timeout=15000)
                    result['http_status'] = response.status
                    if not response.ok:
                        return {**result, 'status': 'http_error'}
                    body = await response.body()
                else:
                    raise ValueError('unsupported_image_url')
                if len(body) > 20 * 1024 * 1024:
                    raise ValueError('image_too_large')
                with Image.open(io.BytesIO(body)) as im:
                    im.verify()
                with Image.open(io.BytesIO(body)) as im:
                    im.load()
                    size, fmt = (im.size, im.format)
                result.update(status='verified', sha256=hashlib.sha256(body).hexdigest(), size=list(size))
                if download:
                    target = folder / 'images' / (result['sha256'] + '.' + fmt.lower())
                    target.parent.mkdir(exist_ok=True)
                    target.write_bytes(body)
                    result['local_path'] = str(target.relative_to(folder))
            except Exception as exc:
                result.update(status='unverified', error=type(exc).__name__ + ': ' + str(exc)[:180])
            return result
    sources = sorted(set((row['source'] for row in manifest)))
    cache = dict(zip(sources, await asyncio.gather(*(check(src) for src in sources))))
    return [{**row, **cache[row['source']]} for row in manifest]

async def save_exam(context, data, args):
    identity = hashlib.sha256(data['page_url'].encode()).hexdigest()[:10]
    folder = args.output / (safe_name(data['paper_title']) + '_' + identity) / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder.mkdir(parents=True)
    data = dict(data)
    snapshots = data.pop('rendered_snapshots', [])
    json_write(folder / 'rendered_dom.json', {'page_url': data['page_url'], 'captured_at': data.get('captured_at'), 'snapshots': snapshots})
    json_write(folder / 'questions.json', data)
    json_write(folder / 'source_provenance.json', {'page_url': data['page_url'], 'captured_at': data.get('captured_at'), 'method': 'normal_rendered_DOM', 'expected_count': data.get('expected_count'), 'source_files': [{'file': name, 'sha256': sha(folder / name)} for name in ('rendered_dom.json', 'questions.json')], 'submission': data.get('submission'), 'material_id_policy': 'local-material: prefix denotes a local content-derived ID'})
    audit, v2 = (validate_exam(data), None)
    try:
        v2 = to_v2(data)
    except ValueError as exc:
        audit['issues'].append(str(exc))
        audit['ok'] = False
    media = await verify_media(context, v2, folder, args.download_images) if v2 else []
    if any((row['status'] != 'verified' for row in media)):
        audit['ok'] = False
        audit['issues'].append('unverified_media')
    status = 'success' if audit['ok'] else 'incomplete'
    if v2:
        json_write(folder / ('paper_v2.json' if audit['ok'] else 'paper_v2_pending.json'), v2)
    json_write(folder / 'audit.json', audit)
    json_write(folder / 'missing.json', {'issues': audit['issues'], 'questions': [r for r in audit['questions'] if not r['ok']], 'warnings': audit['warnings']})
    json_write(folder / 'media_manifest.json', media)
    wb, ws = (Workbook(), None)
    ws = wb.active
    ws.append(['卷名', '题号', 'globalId', '答案', '平台正确率', '状态'])
    for q in data['questions']:
        values = [data['paper_title'], q.get('question_no'), q.get('globalId'), q.get('answer'), q.get('rate'), status]
        ws.append(["'" + v if isinstance(v, str) and v.startswith(('=', '+', '-', '@')) else v for v in values])
    wb.save(folder / 'questions.xlsx')
    result = {'status': status, 'title': data['paper_title'], 'path': str(folder.resolve()), 'questions': len(data['questions']), 'page_url': data['page_url'], 'completed_at': now(), 'version': VERSION, 'issues': audit['issues']}
    if status == 'success':
        result['sha256'] = sha(folder / 'paper_v2.json')
    json_write(folder / 'receipt.json', result)
    return result

async def crawl_current_page(context, page, args, submitted, expected=None, title=None):
    start = time.monotonic()
    if not allowed_page(page.url):
        raise ValueError('只支持正常访问的 fenbi.com HTTPS 页面。')
    await page.locator('app-solution-overall:visible, .correct-answer:visible, .submit-btn:visible').first.wait_for(timeout=30000)
    event = await ensure_solution(page, args, submitted)
    data = await extract_exam_data(page, expected, title, args.max_rounds)
    data['submission'] = event or submitted.get(page.url)
    data['elapsed_capture_seconds'] = round(time.monotonic() - start, 3)
    result = await save_exam(context, data, args)
    result['elapsed_total_seconds'] = round(time.monotonic() - start, 3)
    json_write(Path(result['path']) / 'receipt.json', result)
    return result

async def paper_items(page):
    rows = []
    for i, item in enumerate(await page.locator(PAPER_ITEMS).all()):
        if not await item.is_visible():
            continue
        title = item.locator('.item-info-title,.paper-title').first
        name = (await title.inner_text()).strip() if await title.count() else (await item.inner_text()).strip()
        link = item.locator('a[href]').first
        raw = await link.get_attribute('href') if await link.count() else ''
        href = urljoin(page.url, raw) if raw and (not raw.startswith(('#', 'javascript:'))) else ''
        rows.append({'title': name, 'href': href, 'index': i})
    return rows

def list_signature(rows):
    return tuple(((r['title'], r['href']) for r in rows))

async def click_filter(page, name):
    for loc in await page.locator(FILTER_ITEMS).all():
        if await loc.is_visible() and (await loc.inner_text()).strip() == name:
            await loc.click()
            await page.wait_for_timeout(1000)
            return
    raise RuntimeError('找不到分类：' + name)

async def open_paper(context, paper, filter_name, list_url, round_no, signature):
    worker = await context.new_page()
    try:
        if paper['href'] and allowed_page(paper['href']):
            await worker.goto(paper['href'], wait_until='domcontentloaded')
            return worker
        await worker.goto(list_url, wait_until='domcontentloaded')
        await click_filter(worker, filter_name)
        for _ in range(round_no):
            if not await click_next(worker, NEXT_LIST):
                raise RuntimeError('无法恢复列表页，停止按索引打开。')
        if list_signature(await paper_items(worker)) != signature:
            raise RuntimeError('列表不一致，停止按索引打开。')
        popups = []

        def on_page(p):
            popups.append(p)
        context.on('page', on_page)
        try:
            await worker.locator(PAPER_ITEMS).nth(paper['index']).click()
            await worker.wait_for_timeout(1200)
        finally:
            context.remove_listener('page', on_page)
        if len(popups) > 1:
            for p in popups:
                await p.close()
            raise RuntimeError('多个新窗口，无法确定目标卷。')
        if popups:
            await worker.close()
            worker = popups[0]
            await worker.wait_for_load_state('domcontentloaded')
        return worker
    except Exception:
        await worker.close()
        raise

def valid_receipt(entry):
    try:
        path = Path(entry['path'])
        return entry.get('version') == VERSION and entry.get('status') == 'success' and (sha(path / 'paper_v2.json') == entry.get('sha256')) and json.loads((path / 'audit.json').read_text(encoding='utf-8'))['ok']
    except (OSError, KeyError, ValueError):
        return False

def complete_entries(output, today_only=False):
    found = {}
    for p in output.glob('*/*/receipt.json'):
        try:
            e = json.loads(p.read_text(encoding='utf-8'))
            if (not today_only or e.get('completed_at', '').startswith(now()[:10])) and valid_receipt(e):
                identity = e['title']
                found[identity] = e
        except (ValueError, OSError):
            continue
    return found

def daily_entries(output):
    return complete_entries(output, today_only=True)

async def crawl_category(context, page, name, args, submitted):
    await click_filter(page, name)
    list_url, seen_pages, seen_papers, results = (page.url, set(), set(), [])
    for round_no in range(args.max_rounds):
        rows = await paper_items(page)
        signature = list_signature(rows)
        if not rows or signature in seen_pages:
            break
        seen_pages.add(signature)
        for paper in rows:
            if len(daily_entries(args.output)) >= args.daily_target:
                return results
            key = paper['href'] or name + '|' + paper['title']
            if key in seen_papers:
                continue
            seen_papers.add(key)
            checkpoint = args.output / 'checkpoint.json'
            cp = json.loads(checkpoint.read_text(encoding='utf-8')) if checkpoint.exists() else {}
            if valid_receipt(cp.get(key, {})):
                continue
            if paper['title'] in complete_entries(args.output):
                continue
            worker = None
            try:
                worker = await open_paper(context, paper, name, list_url, round_no, signature)
                result = await crawl_current_page(context, worker, args, submitted, title=paper['title'])
                cp[key] = result
                json_write(checkpoint, cp)
                results.append(result)
                LOG.info('%s | %s | %s题', result['status'], result['title'], result['questions'])
            except Exception as exc:
                results.append({'status': 'failed', 'title': paper['title'], 'message': str(exc)})
                LOG.warning('本卷失败，继续下一卷：%s', exc)
            finally:
                if worker:
                    await worker.close()
            await page.wait_for_timeout(1200)
        if not await click_next(page, NEXT_LIST):
            break
    return results

def options():
    p = argparse.ArgumentParser(description='粉笔正常页面采集、整卷核验、当前网站V2输出')
    p.add_argument('--output', type=Path, default=Path('fenbi_output'))
    p.add_argument('--profile', type=Path, default=Path('fenbi_browser_profile'))
    p.add_argument('--browser', choices=['chromium', 'chrome'], default='chromium')
    p.add_argument('--headless', action='store_true', help='仅已有可用登录时使用；须同时给--plan')
    p.add_argument('--auto-submit', action=argparse.BooleanOptionalAction, default=True, help='默认开启；仅本人已授权练习卷；--no-auto-submit可关闭')
    p.add_argument('--download-images', action='store_true', help='额外保存图片副本，不改写HTML原地址')
    p.add_argument('--daily-target', type=int, default=5)
    p.add_argument('--max-rounds', type=int, default=300)
    p.add_argument('--plan', type=Path, help='JSON数组，每条含url/title/expected_count')
    p.add_argument('--expected-count', type=int, help='仅单卷模式，须核实后填写')
    args = p.parse_args()
    if args.daily_target < 1 or args.max_rounds < 1 or (args.expected_count is not None and args.expected_count < 1):
        p.error('数量参数必须为正整数')
    if args.plan and args.expected_count:
        p.error('计划模式请分别设置每卷expected_count')
    if args.headless and (not args.plan):
        p.error('无界面模式必须给--plan；首次登录请用有界面模式')
    return args

async def main():
    args = options()
    args.output.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, handlers=[logging.StreamHandler(), logging.FileHandler(args.output / 'crawler.log', encoding='utf-8')])
    results, submitted, single_mode = ([], {}, False)
    async with async_playwright() as pw:
        launch = {'headless': args.headless, 'viewport': {'width': 1440, 'height': 900}}
        if args.browser == 'chrome':
            launch['channel'] = 'chrome'
        context = await pw.chromium.launch_persistent_context(str(args.profile.resolve()), **launch)
        context.set_default_navigation_timeout(60000)
        context.set_default_timeout(10000)
        try:
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(START_URL, wait_until='domcontentloaded')
            print('请在浏览器正常登录并打开目标页。登录目录勿共享。自动交卷：', args.auto_submit)
            print('占位提交不代表真实学习成绩；平台端练习历史可能被改变，本程序不会清理平台记录。')
            if not args.headless:
                await asyncio.to_thread(input, '准备好后按Enter：')
            if args.plan:
                plan = json.loads(args.plan.read_text(encoding='utf-8'))
                if not isinstance(plan, list):
                    raise ValueError('plan必须是数组')
                for target in plan:
                    if len(daily_entries(args.output)) >= args.daily_target:
                        break
                    if not allowed_page(target.get('url', '')) or not target.get('title') or type(target.get('expected_count')) is not int or (target['expected_count'] < 1):
                        raise ValueError('每条计划须有fenbi HTTPS url、完整title、正整数expected_count')
                    if any((e['page_url'] == target['url'] or e['title'] == target['title'] for e in complete_entries(args.output).values())):
                        continue
                    try:
                        await page.goto(target['url'], wait_until='domcontentloaded')
                        results.append(await crawl_current_page(context, page, args, submitted, target['expected_count'], target['title']))
                    except Exception as exc:
                        results.append({'status': 'failed', 'title': target['title'], 'message': str(exc)})
            else:
                mode = (await asyncio.to_thread(input, '模式1=当前卷，2=指定分类，3=全部可见分类：')).strip()
                if mode == '1':
                    single_mode = True
                    results.append(await crawl_current_page(context, page, args, submitted, args.expected_count))
                else:
                    if args.expected_count:
                        raise ValueError('--expected-count仅允许单卷模式')
                    names = []
                    for x in await page.locator(FILTER_ITEMS).all():
                        if await x.is_visible():
                            name = (await x.inner_text()).strip()
                            if name and name not in names:
                                names.append(name)
                    if mode == '2':
                        print('\n'.join((f'{i + 1}. {n}' for i, n in enumerate(names))))
                        index = int(await asyncio.to_thread(input, '分类编号：'))
                        if not 1 <= index <= len(names):
                            raise ValueError('分类编号无效')
                        names = [names[index - 1]]
                    elif mode != '3':
                        raise ValueError('无效模式')
                    for name in names:
                        if len(daily_entries(args.output)) >= args.daily_target:
                            break
                        results.extend(await crawl_category(context, page, name, args, submitted))
        finally:
            await context.close()
            entries = list(daily_entries(args.output).values())
            unique = set()
            for e in entries:
                d = json.loads((Path(e['path']) / 'paper_v2.json').read_text(encoding='utf-8'))
                unique.update((q['globalId'] for q in d['questions']))
            summary = {'date': now()[:10], 'timezone': 'Asia/Shanghai', 'target': args.daily_target, 'complete_papers': len(entries), 'target_met': len(entries) >= args.daily_target, 'question_positions': sum((e['questions'] for e in entries)), 'unique_globalIds': len(unique), 'papers': entries, 'this_run': results, 'website_import_verified': False, 'note': '本地核验；还需当前网站实际导入及导出复核'}
            json_write(args.output / ('daily_' + now()[:10] + '.json'), summary)
            print(json.dumps({k: summary[k] for k in ('complete_papers', 'target', 'target_met', 'question_positions', 'unique_globalIds')}, ensure_ascii=False))
    if single_mode:
        return 0 if results and results[-1]['status'] == 'success' else 2
    return 0 if summary['target_met'] else 2
if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
