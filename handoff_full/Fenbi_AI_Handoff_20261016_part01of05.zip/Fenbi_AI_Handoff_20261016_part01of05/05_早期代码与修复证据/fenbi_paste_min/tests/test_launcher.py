from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch
import subprocess
import windows_launcher as launcher


class LauncherTests(TestCase):
    def test_new_folder_prepares_once_then_reuses_environment(self):
        with TemporaryDirectory(prefix='fenbi space ') as td:
            root=Path(td);(root/'requirements.txt').write_text('example==1')
            with patch.object(launcher,'run') as run, patch.object(launcher,'ready',return_value=True):
                python,env=launcher.prepare(root)
                self.assertEqual(run.call_count,3)
                self.assertEqual(env['PLAYWRIGHT_BROWSERS_PATH'],str(root/'browser_cache'))
                self.assertEqual(env['PIP_REQUIRE_VIRTUALENV'],'true')
                python.parent.mkdir(parents=True);python.touch()
                run.reset_mock()
                launcher.prepare(root)
                run.assert_not_called()

    def test_partial_environment_is_not_deleted(self):
        with TemporaryDirectory() as td:
            root=Path(td);(root/'requirements.txt').write_text('example==1')
            (root/'.venv').mkdir();sentinel=root/'.venv'/'keep.txt';sentinel.write_text('keep')
            with self.assertRaises(RuntimeError),patch.object(launcher,'run') as run:
                launcher.prepare(root)
            self.assertEqual(sentinel.read_text(),'keep');run.assert_not_called()

    def test_install_failure_does_not_start_collector(self):
        with patch.object(launcher,'prepare',side_effect=subprocess.CalledProcessError(1,['pip'])),patch.object(launcher.subprocess,'run') as run:
            self.assertEqual(launcher.main(),1)
            run.assert_not_called()

    def test_failed_validation_exit_code_is_preserved(self):
        with TemporaryDirectory() as td:
            root=Path(td)
            with patch.object(launcher,'prepare',return_value=(root/'python.exe',{})),patch.object(launcher.subprocess,'run',return_value=SimpleNamespace(returncode=2)) as run:
                self.assertEqual(launcher.main(root),2)
                argv=run.call_args.args[0]
                self.assertEqual(argv[argv.index('--daily-target')+1],'5')
                self.assertEqual(run.call_args.kwargs['cwd'],root)
