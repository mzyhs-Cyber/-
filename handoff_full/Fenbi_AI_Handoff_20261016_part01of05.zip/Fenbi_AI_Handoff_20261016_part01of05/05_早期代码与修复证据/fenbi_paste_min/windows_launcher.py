from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parent

def run(command, root, env):
    subprocess.run([str(x) for x in command], cwd=root, env=env, check=True)

def ready(python, browser_dir, root, env):
    if not python.is_file():
        return False
    probe = 'from pathlib import Path; import bs4,openpyxl,PIL,tzdata; from playwright.sync_api import sync_playwright; p=sync_playwright().start(); ok=Path(p.chromium.executable_path).is_file(); p.stop(); raise SystemExit(0 if ok else 1)'
    return subprocess.run([str(python), '-c', probe], cwd=root, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

def prepare(root=ROOT):
    if sys.version_info < (3, 10):
        raise RuntimeError('需要 Python 3.10 或更新版本，请先安装后重新双击。')
    venv = root / '.venv'
    python = venv / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    browser_dir = root / 'browser_cache'
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PLAYWRIGHT_BROWSERS_PATH=str(browser_dir), PIP_REQUIRE_VIRTUALENV='true')
    requirements = root / 'requirements.txt'
    fingerprint = hashlib.sha256(requirements.read_bytes() + sys.version.encode()).hexdigest()
    stamp = root / '.setup_complete.json'
    if not python.is_file():
        if venv.exists():
            raise RuntimeError('发现不完整的 .venv 文件夹。请将本包重新解压到新文件夹，不要删除题库或登录目录。')
        print('\n[1/3] 正在创建本文件夹专用的 Python 环境……', flush=True)
        run([sys.executable, '-m', 'venv', venv], root, env)
    previous = {}
    try:
        previous = json.loads(stamp.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        pass
    if previous.get('fingerprint') != fingerprint or not ready(python, browser_dir, root, env):
        print('\n[2/3] 首次安装依赖，可能需要几分钟，请保持网络连接……', flush=True)
        run([python, '-m', 'pip', 'install', '-r', requirements], root, env)
        print('\n[3/3] 正在安装采集专用 Chromium 浏览器……', flush=True)
        run([python, '-m', 'playwright', 'install', 'chromium'], root, env)
        if not ready(python, browser_dir, root, env):
            raise RuntimeError('依赖或浏览器未准备完成，请保留报错信息。')
        stamp.write_text(json.dumps({'fingerprint': fingerprint}), encoding='utf-8')
    return (python, env)

def main(root=ROOT):
    print('粉笔采集器 · Windows 双击启动版', flush=True)
    print('首次启动会安装依赖；后续自动复用。请保持此窗口打开。', flush=True)
    try:
        python, env = prepare(root)
        print('\n即将打开采集浏览器：请在网页中正常登录粉笔。', flush=True)
        print('打开目标卷或列表后，回到此窗口按 Enter。模式 1 先试一卷；模式 2/3 批量处理。', flush=True)
        print('批量目标默认为五套；A/B 卷分别保存。自动交卷默认开启，用于打开解析。', flush=True)
        result = subprocess.run([str(python), str(root / 'fenbi_crawler_v2.py'), '--daily-target', '5', '--profile', str(root / 'fenbi_browser_profile'), '--output', str(root / 'fenbi_output')], cwd=root, env=env)
        if result.returncode == 0:
            print('\n本次任务已按所选模式完成。', flush=True)
        elif result.returncode == 2:
            print('\n本次有待补卷，或批量任务未达到五套。请查看输出报告。', flush=True)
        else:
            print('\n程序遇到错误。请保留窗口里的报错，发给助手排查。', flush=True)
        print('输出位置：' + str(root / 'fenbi_output'), flush=True)
        return result.returncode
    except subprocess.CalledProcessError as exc:
        print('\n安装步骤失败，尚未开始采集。请保留上方完整报错，联网后可重新双击。', flush=True)
        return exc.returncode or 1
    except (OSError, RuntimeError) as exc:
        print('\n启动失败：' + str(exc), flush=True)
        return 1
if __name__ == '__main__':
    raise SystemExit(main())
