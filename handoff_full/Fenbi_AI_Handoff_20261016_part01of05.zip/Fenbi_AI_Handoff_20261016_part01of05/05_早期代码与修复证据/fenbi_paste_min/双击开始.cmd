@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto check_python
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
:check_python
where python >nul 2>&1
if errorlevel 1 goto missing_python
python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
:missing_python
echo.
echo Python 3.10+ was not found. Opening the official download page.
echo Install Python, check "Add python.exe to PATH", then double-click again.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1
:use_py
py -3 -X utf8 "%~dp0windows_launcher.py"
set "RESULT=%ERRORLEVEL%"
goto finished
:use_python
python -X utf8 "%~dp0windows_launcher.py"
set "RESULT=%ERRORLEVEL%"
:finished
echo.
echo Window kept open. Copy any error before closing.
pause
exit /b %RESULT%
