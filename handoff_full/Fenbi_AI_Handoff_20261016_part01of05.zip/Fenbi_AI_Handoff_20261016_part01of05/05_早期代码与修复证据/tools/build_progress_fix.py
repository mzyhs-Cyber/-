import ast
from pathlib import Path

NEXT_CODE = '''
async def click_next(page, selector):
    async def step():
        kind = 'question' if selector == NEXT_QUESTION else 'list'
        count = await page.evaluate(r"""kind => {
          const visible=e=>!!e.getClientRects().length && getComputedStyle(e).visibility!=='hidden';
          const candidates=[...document.querySelectorAll('button,a,[role="button"],.next-question,.pagination-next,[aria-label="Next"]')].filter(e=>{
            if(!visible(e)||e.closest('[disabled],[aria-disabled="true"],.disabled,.ant-pagination-disabled'))return false;
            const text=(e.innerText||e.getAttribute('aria-label')||'').trim();
            return kind==='question' ? e.matches('.next-question')||/^下一题(?:\\s*[>›»])?$/.test(text) : e.matches('.pagination-next,[aria-label="Next"]')||/^(下一页|Next)(?:\\s*[>›»])?$/.test(text);
          });
          const leaves=candidates.filter(e=>!candidates.some(other=>other!==e&&e.contains(other)));
          for(const e of document.querySelectorAll('[data-fenbi-next-control]'))e.removeAttribute('data-fenbi-next-control');
          if(leaves.length===1)leaves[0].setAttribute('data-fenbi-next-control','1');
          return leaves.length;
        }""", kind)
        if count == 0:
            return False
        if count != 1:
            raise RuntimeError('下一题或下一页按钮不唯一，已停止自动点击。')
        await page.locator('[data-fenbi-next-control="1"]').click(timeout=4000)
        await asyncio.sleep(0.6)
        return True
    try:
        return await asyncio.wait_for(step(), timeout=BROWSER_QUERY_SECONDS)
    except TimeoutError:
        raise RuntimeError('browser_navigation_timeout') from None
    except Exception as exc:
        raise RuntimeError('browser_navigation_error:' + type(exc).__name__) from None
'''

CHECKPOINT = '''
print(f"[采集进度] 已读取 {len(questions)} 题；页面声明题数：{expected or (next(iter(counts)) if len(counts)==1 else '尚未识别')}", flush=True)
if progress_dir is not None:
    checkpoint_folder = Path(progress_dir)
    checkpoint_folder.mkdir(parents=True, exist_ok=True)
    json_write(checkpoint_folder / 'capture_checkpoint.json', {
        'schema_version': VERSION, 'paper_title': next(iter(titles)) if len(titles)==1 else '未命名试卷',
        'page_url': page.url, 'expected_count': expected or (next(iter(counts)) if len(counts)==1 else None),
        'questions': list(questions.values()), 'collection_errors': sorted(errors),
        'captured_at': now(), 'observations': observations, 'rendered_snapshots': list(snapshots.values()),
        'status': 'checkpoint_only_not_import_ready'})
'''


def statements(code):
    return ast.parse(code).body


def error_handler(label):
    return ast.ExceptHandler(type=ast.Name(id='Exception',ctx=ast.Load()),
        name='step_error', body=statements(f"errors.add({label!r} + ':' + str(step_error))\nbreak"))


def transform(source):
    if 'checkpoint_only_not_import_ready' in source:
        raise RuntimeError('进度补丁已经安装，不需要重复安装。')
    tree=ast.parse(source)
    found=set()
    for index, fn in enumerate(tree.body):
        if isinstance(fn, ast.AsyncFunctionDef) and fn.name=='click_next':
            tree.body[index]=statements(NEXT_CODE)[0]; found.add(fn.name)
        if isinstance(fn, ast.AsyncFunctionDef) and fn.name=='extract_exam_data':
            found.add(fn.name)
            fn.args.args.append(ast.arg(arg='progress_dir'));fn.args.defaults.append(ast.Constant(value=None))
            loop=next(x for x in fn.body if isinstance(x,ast.For))
            fn.body.insert(fn.body.index(loop),statements('capture_started = time.monotonic()')[0])
            output=statements("if time.monotonic() - capture_started > 90:\n    errors.add('capture_time_limit')\n    break")
            for node in loop.body:
                if isinstance(node,ast.Assign) and isinstance(node.value,ast.Await) and isinstance(node.value.value,ast.Call) and isinstance(node.value.value.func,ast.Attribute) and node.value.value.func.attr=='evaluate':
                    call=node.value.value
                    node.value.value=ast.Call(func=ast.Attribute(value=ast.Name(id='asyncio',ctx=ast.Load()),attr='wait_for',ctx=ast.Load()),args=[call],keywords=[ast.keyword(arg='timeout',value=ast.Constant(value=12))])
                    output.append(ast.Try(body=[node],handlers=[error_handler('browser_read_failed')],orelse=[],finalbody=[]))
                    continue
                if isinstance(node,ast.If) and isinstance(node.test,ast.Await) and isinstance(node.test.value,ast.Call) and isinstance(node.test.value.func,ast.Name) and node.test.value.func.id=='click_next':
                    output.append(ast.Try(body=[node],handlers=[error_handler('next_control_failed')],orelse=[],finalbody=[]))
                    continue
                if isinstance(node,ast.Expr) and isinstance(node.value,ast.Await) and isinstance(node.value.value,ast.Call) and isinstance(node.value.value.func,ast.Attribute) and node.value.value.func.attr=='wait_for_timeout':
                    node=statements('await asyncio.sleep(0.7)')[0]
                output.append(node)
                if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='observations':
                    output.extend(statements(CHECKPOINT))
            loop.body=output
            ret=fn.body[-1]
            if not isinstance(ret,ast.Return):
                raise RuntimeError('采集函数结构不同，未修改文件。')
            fn.body[-1:]=[ast.Assign(targets=[ast.Name(id='collected_data',ctx=ast.Store())],value=ret.value)]+statements("if progress_dir is not None:\n    json_write(Path(progress_dir) / 'capture_checkpoint.json', {**collected_data, 'status':'capture_finished_needs_validation'})\nreturn collected_data")
        if isinstance(fn,ast.AsyncFunctionDef) and fn.name=='crawl_current_page':
            fn.body.insert(0,statements("print('[步骤1] 正在检查试卷和解析页……', flush=True)")[0])
            for node in ast.walk(fn):
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='extract_exam_data':
                    node.keywords.append(ast.keyword(arg='progress_dir',value=ast.Attribute(value=ast.Name(id='args',ctx=ast.Load()),attr='output',ctx=ast.Load())))
        if isinstance(fn,ast.AsyncFunctionDef) and fn.name=='verify_media':
            fn.body.insert(0,statements("print('[图片检查] 开始核验图片，网络检查可能需要几分钟；题目已先保存。', flush=True)")[0])
    if found!={'click_next','extract_exam_data'}:
        raise RuntimeError('程序版本不同，未修改文件。')
    after_future=max((i+1 for i,x in enumerate(tree.body) if isinstance(x,ast.ImportFrom) and x.module=='__future__'),default=0)
    tree.body.insert(after_future,ast.Assign(targets=[ast.Name(id='BROWSER_QUERY_SECONDS',ctx=ast.Store())],value=ast.Constant(value=6)))
    ast.fix_missing_locations(tree)
    result=ast.unparse(tree)+'\n'
    compile(result,'patched_collector.py','exec')
    return result


if __name__=='__main__':
    import sys
    source=Path(sys.argv[1]);destination=Path(sys.argv[2])
    destination.write_text(transform(source.read_text(encoding='utf-8-sig')),encoding='utf-8')
