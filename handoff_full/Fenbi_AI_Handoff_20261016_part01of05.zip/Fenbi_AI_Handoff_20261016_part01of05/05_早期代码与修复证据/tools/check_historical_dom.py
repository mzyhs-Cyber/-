import asyncio,json,time,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from playwright.async_api import async_playwright
sys.path.insert(0,'/workspace/-')
from fenbi_crawler_v2 import extract_exam_data,click_next,NEXT_QUESTION
from bank_core import parse_question,validate_exam,to_v2
r=Path('/workspace/handoff_read/本窗口完整交接包_20261016')
raw=json.loads((r/'05_原工作目录/admin-capture/rendered-dom.json').read_text())
final=json.loads((r/'01_当前可导入题库/2026国考行政执法_130题_V2.json').read_text())
by_id={q['globalId']:q for q in final['questions']};rendered={};groups={}
for row in raw['questions']:
 gid=parse_question(row['html'],'https://www.fenbi.com')['globalId'];q=by_id[gid]
 rendered[row['titleId']]=f'<app-ti data-question-no="{q["order"]}" data-subject="{q["subject"]}">'+row['html']+'</app-ti>'
for mat in raw['materials']:
 keys=mat['questionTitles'];group='<div class="question-group">'+mat['materialHtml']+''.join(rendered[k] for k in keys)+'</div>'
 for k in keys:groups[k]=(keys[0],group)
parts=[];done=set()
for row in raw['questions']:
 key=row['titleId']
 if key in groups:
  first,group=groups[key]
  if first not in done:parts.append(group);done.add(first)
 else:parts.append(rendered[key])
html='<meta charset="utf-8"><h1>'+final['name']+'</h1><div data-question-count="130"></div>'+''.join(parts)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium');ctx=await browser.new_context();page=await ctx.new_page()
  async def route(r):
   if r.request.url=='https://www.fenbi.com/local-fixture':await r.fulfill(body=html,content_type='text/html;charset=utf-8')
   else:await r.abort()
  await ctx.route('**/*',route);await page.goto('https://www.fenbi.com/local-fixture',wait_until='domcontentloaded')
  with TemporaryDirectory() as td:
   started=time.monotonic();data=await extract_exam_data(page,progress_dir=Path(td));seconds=round(time.monotonic()-started,3)
   audit=validate_exam(data);v=to_v2(data)
   next_started=time.monotonic();has_next=await click_next(page,NEXT_QUESTION);query_seconds=round(time.monotonic()-next_started,3)
   report={'fixture':'historical DOM with verified order/subject/count wrappers; all network requests intercepted','questions':len(data['questions']),'audit_ok':audit['ok'],'issues':audit['issues'],'material_groups':len(v['materials']),'material_questions':sum(bool(n['materialKeys']) for c in v['card']['children'] for n in c['children']),'answers_match':sum(q['answer']==by_id[q['globalId']]['answer'] for q in v['questions']),'rates_match':sum(q['rate']==by_id[q['globalId']]['rate'] for q in v['questions']),'checkpoint_saved':(Path(td)/'capture_checkpoint.json').is_file(),'capture_seconds':seconds,'next_control_present':has_next,'next_query_seconds':query_seconds,'live_fenbi_verified':False,'real_windows_verified':False}
   Path('/workspace/-/HISTORICAL_DOM_CHECK.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
   assert audit['ok'],audit['issues']
   assert report['questions']==report['answers_match']==report['rates_match']==130
   assert report['material_groups']==5 and report['material_questions']==25
  await browser.close()
asyncio.run(main())
