"""Split the full handoff into five independently verifiable upload ZIPs."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile


def split(source, destination):
    source, destination = Path(source), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as archive:
        manifest_name = next(n for n in archive.namelist() if n.endswith('/MANIFEST.json'))
        prefix = manifest_name.removesuffix('MANIFEST.json')
        manifest = json.loads(archive.read(manifest_name))
        rows = manifest['files']
        large = sorted(r['path'] for r in rows if re.search(r'第0[1-4]卷_共04卷\.zip$', r['path']))
        if len(large) != 4:
            raise ValueError('Expected the four original handoff volume ZIPs')
        groups = [[r['path'] for r in rows if r['path'] not in large]] + [[name] for name in large]
        index = {'parts': [{'part': i + 1, 'filename': f'Fenbi_AI_Handoff_20261016_part{i+1:02d}of05.zip',
                            'primary_files': group} for i, group in enumerate(groups)],
                 'full_source_zip': source.name, 'source_commit': manifest['source_commit'],
                 'instructions': 'Upload all five ZIPs to the next AI. Part 1 contains all code, requirements, current issues, history and key completed results; parts 2-5 preserve the original four source volumes. Every part has an independent hash manifest. Browser credentials are excluded.'}
        covered = set()
        reports = []
        for i, group in enumerate(groups):
            payload = {name: archive.read(prefix + name) for name in group}
            covered.update(group)
            for common in ['START_HERE.md', 'NEXT_AI_PROMPT.txt', 'code/handoff/verify_package.py']:
                payload.setdefault(common, archive.read(prefix + common))
            payload['VOLUME_INDEX.json'] = json.dumps(index, ensure_ascii=False, indent=2).encode('utf-8')
            if i == 0:
                payload['ORIGINAL_FULL_MANIFEST.json'] = archive.read(manifest_name)
            part_manifest = {'schema_version': 1, 'source_commit': manifest['source_commit'],
                'kind': 'local_full_volume', 'volume_number': i + 1, 'volume_total': 5,
                'manifest_self_excluded': True,
                'files': [{'path': n, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
                          for n, b in sorted(payload.items())]}
            payload['MANIFEST.json'] = json.dumps(part_manifest, ensure_ascii=False, indent=2).encode('utf-8')
            target = destination / index['parts'][i]['filename']
            root = f'Fenbi_AI_Handoff_20261016_part{i+1:02d}of05/'
            with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as out:
                for name, body in sorted(payload.items()):
                    out.writestr(root + name, body)
            if target.stat().st_size > 32 * 1024 * 1024:
                raise ValueError('Part exceeds the 32 MiB upload tool limit')
            reports.append({'filename': target.name, 'bytes': target.stat().st_size,
                            'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
        if covered != {r['path'] for r in rows}:
            raise ValueError('Some full-package payload files were omitted')
        summary = {'status': 'split_complete', 'all_full_payload_files_covered': True,
                   'full_payload_files': len(covered), 'parts': reports}
        (destination / 'VOLUMES_CHECK.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    split(sys.argv[1], sys.argv[2])
